# 🌸 Sambo Bot

Bot Discord bergaya uwu bot. Prefix: **`s` + perintah** (contoh: `shunt`, `sdaily`, `sbalance`, `sslots 100`).
Boleh juga pakai spasi: `s hunt`.

## Cara menjalankan
1. Buat bot di https://discord.com/developers/applications → tab **Bot** → copy token.
2. Di tab **Bot**, aktifkan **MESSAGE CONTENT INTENT**.
3. Undang bot dengan scope `bot`, izin: Send Messages, Embed Links, Attach Files, Read Message History.
4. Salin `.env.example` menjadi `.env`, isi `DISCORD_TOKEN`.
5. Jalankan:
```
npm install
npm start
```
Data tersimpan di `data/db.json` (otomatis dibuat). Untuk hosting, pastikan folder `data/` persisten.

## Owner
`OWNER_ID` = `834478964818182165` (@smbooo_). Owner mendapat saldo 1 triliun coin (terisi ulang otomatis jika < 1 miliar),
tanpa cooldown & batas taruhan, serta akses `sownerhelp` (give, remove, set, giveitem, giveanimal, giveweapon, edit, get, resetuser, dbbackup).

## Perintah
- **Hunt**: autohunt boostanimals dex finishhunt hunt sacrifice sell team upgrade zoo zooshop
- **Battle**: battle battlepvp battlesetting clan
- **Weapons**: combolist crate dismantle fabledcrate legendarycrate redfabledcrate weapon weaponinfo
- **Items**: fabledbox inventory lootbox pinkuwubox protectioncard redbox use uwubox balance boostlevel daily deposit level mystats quest ranking weekly withdraw work
- **Trade**: transfer transferbox transfercrate transferpoint transfershard transferspecialticket transferticket
- **Gamble**: amongus blackjack blackjackmultiplayer coinflip fishing klahklok klahklokmultiplayer mines pokkdeang pokkdeangmultiplayer slots slotsmultiplayer

Ketik `shelp` untuk daftar, `shelp <perintah>` untuk detail.
