const db = require('../lib/db');
const registry = require('../lib/registry');
const { E } = require('../lib/util');

const ORDER = ['Hunt', 'Battle', 'Weapons', 'Items', 'Trade', 'Gamble'];
module.exports = [
  {
    name: 'help', aliases: ['h2', 'commands', 'menu'], cat: 'Info', desc: 'Daftar perintah', usage: 'shelp [perintah]',
    async run({ args, reply, u }) {
      if (args[0]) {
        const cmd = registry.map.get(args[0].toLowerCase());
        if (!cmd || (cmd.owner && !db.isOwner(u.id))) return reply('Perintah tidak ditemukan.');
        return reply({ embeds: [E(`📘 s${cmd.name}`, `${cmd.desc}\n\n**Cara pakai:** \`${cmd.usage || 's' + cmd.name}\`${cmd.aliases && cmd.aliases.length ? `\n**Alias:** ${cmd.aliases.map(a => `\`s${a}\``).join(' ')}` : ''}`)] });
      }
      const cats = [...ORDER]; if (db.isOwner(u.id)) cats.push('Owner');
      const fields = cats.map(cn => {
        const list = registry.list.filter(c => c.cat === cn);
        return `**${{ Hunt: '🏹', Battle: '⚔️', Weapons: '🗡️', Items: '🎒', Trade: '🤝', Gamble: '🎲', Owner: '👑' }[cn]} ${cn} — ${list.length}**\n${list.map(c => `\`${c.name}\``).join(' ')}`;
      });
      return reply({ embeds: [E('🌸 Sambo Bot', `Prefix: **s** + perintah, contoh \`shunt\`, \`sdaily\`, \`sbalance\`.\nDetail perintah: \`shelp <perintah>\`\n\n${fields.join('\n\n')}`)] });
    },
  },
  { name: 'ping', cat: 'Info', desc: 'Cek latensi bot', usage: 'sping', async run({ reply, client }) { return reply(`🏓 Pong! ${Math.round(client.ws.ping)}ms`); } },
];
