const db = require('../lib/db');
const D = require('../lib/data');
const { E, fmt, dur, parseAmt } = require('../lib/util');
const cat = 'Items';

function openMany(u, key, args) {
  const have = D.count(u, key);
  if (!have) return { err: `Kamu tidak punya ${D.ITEM_NAME(key).n}.` };
  const n = args[0] ? parseAmt(args[0], have) : 1;
  if (!n || n > have) return { err: `Kamu hanya punya ${have}.` };
  const open = Math.min(n, 20);
  const out = [];
  for (let i = 0; i < open; i++) out.push(...D.openBox(u, key));
  D.addItem(u, key, -open);
  // gabungkan baris duplikat
  const m = {};
  out.forEach(l => { m[l] = (m[l] || 0) + 1; });
  return { open, text: Object.entries(m).map(([l, c]) => (c > 1 ? `${l} ×${c}` : l)).join('\n') };
}
function boxCmd(key, aliases = []) {
  const info = D.BOXES[key];
  return {
    name: key, aliases, cat, desc: `Buka ${info.n}. Tanpa angka = buka 1, atau 'all'`, usage: `s${key} [jumlah|all]`,
    async run({ u, args, reply }) {
      const r = openMany(u, key, args);
      if (r.err) return reply({ embeds: [E(`${info.e} ${info.n}`, r.err)] });
      return reply({ embeds: [E(`${info.e} Membuka ${r.open}× ${info.n}`, r.text.slice(0, 3900), { footer: `Sisa: ${D.count(u, key)}` })] });
    },
  };
}

module.exports = [
  {
    name: 'inventory', aliases: ['inv', 'i'], cat, desc: 'Lihat isi inventory', usage: 'sinventory',
    async run({ u, reply, msg }) {
      const lines = [];
      for (const k of Object.keys(D.BOXES)) if (u.items[k]) lines.push(`${D.BOXES[k].e} ${D.BOXES[k].n} ×${u.items[k]}  \`s${k}\``);
      for (const k of Object.keys(D.CRATES)) if (u.crates[k]) lines.push(`${D.CRATES[k].e} ${D.CRATES[k].n} ×${u.crates[k]}  \`s${k}\``);
      if (u.items.protectioncard) lines.push(`🛡️ Protection Card ×${u.items.protectioncard}  \`suse protectioncard\``);
      if (u.ticket) lines.push(`🎫 Ticket ×${u.ticket}`);
      if (u.specialticket) lines.push(`🌟 Special Ticket ×${u.specialticket}`);
      if (u.shard) lines.push(`💎 Shard ×${fmt(u.shard)}`);
      if (u.point) lines.push(`✨ Point ×${fmt(u.point)}`);
      lines.push(`⚔️ Senjata ×${u.weapons.length}  \`sweapon\``);
      const prot = (u.boosts.protect || 0) > Date.now() ? `\n🛡️ Proteksi aktif: ${dur(u.boosts.protect - Date.now())}` : '';
      return reply({ embeds: [E(`🎒 Inventory ${msg.author.username}`, lines.join('\n') + prot)] });
    },
  },
  boxCmd('lootbox', ['lb']),
  boxCmd('uwubox', ['ub']),
  boxCmd('pinkuwubox', ['pub']),
  boxCmd('redbox', ['rb']),
  boxCmd('fabledbox', ['fb']),
  {
    name: 'protectioncard', aliases: ['pc'], cat, desc: 'Kartu proteksi 24 jam (coin aman saat kalah PvP). `sprotectioncard buy`', usage: 'sprotectioncard [buy]',
    async run({ u, args, reply }) {
      if ((args[0] || '').toLowerCase() === 'buy') {
        if (u.coin < 10000) return reply('Butuh 10,000 coin.');
        u.coin -= 10000; D.addItem(u, 'protectioncard', 1);
      }
      const act = (u.boosts.protect || 0) > Date.now() ? `Aktif: ${dur(u.boosts.protect - Date.now())}` : 'Tidak aktif';
      return reply({ embeds: [E('🛡️ Protection Card', `Punya: **${u.items.protectioncard || 0}**\nStatus: **${act}**\n\nAktifkan: \`suse protectioncard\`\nBeli: \`sprotectioncard buy\` (10,000 coin)`)] });
    },
  },
  {
    name: 'use', aliases: ['open', 'u'], cat, desc: 'Pakai item / buka box. `suse <item> [jumlah]`', usage: 'suse <item> [jumlah]',
    async run({ u, args, reply }) {
      const k = (args[0] || '').toLowerCase();
      if (k === 'protectioncard') {
        if (!u.items.protectioncard) return reply('Kamu tidak punya Protection Card.');
        D.addItem(u, 'protectioncard', -1);
        u.boosts.protect = Math.max(Date.now(), u.boosts.protect || 0) + 864e5;
        return reply({ embeds: [E('🛡️ Protection Card', `Proteksi aktif **${dur(u.boosts.protect - Date.now())}**.`)] });
      }
      if (D.BOXES[k]) {
        const r = openMany(u, k, args.slice(1));
        if (r.err) return reply(r.err);
        return reply({ embeds: [E(`${D.BOXES[k].e} Membuka ${r.open}× ${D.BOXES[k].n}`, r.text.slice(0, 3900))] });
      }
      if (D.CRATES[k]) return reply(`Pakai perintah \`s${k}\` untuk membuka crate.`);
      return reply('Item tidak dikenali. Lihat `sinventory`.');
    },
  },
];
