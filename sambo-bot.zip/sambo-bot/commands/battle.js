const db = require('../lib/db');
const D = require('../lib/data');
const { E, fmt, cap, dur, cooldown, rand, getTarget, parseAmt, addXp, track } = require('../lib/util');
const { btn, rowOf, ButtonStyle } = require('../lib/game');
const cat = 'Battle';

const clanKey = n => String(n).toLowerCase();
const clanOf = u => (u.clan ? db.raw.clans[clanKey(u.clan)] : null);
const unitsText = us => us.map(x => x.emoji).join(' ');

module.exports = [
  {
    name: 'battle', aliases: ['b', 'fight'], cat, desc: 'Lawan monster dengan team kamu (cooldown 20 detik)', usage: 'sbattle',
    async run({ u, reply }) {
      const T = D.buildTeam(u);
      if (!T.units.length) return reply('Team kosong! Pakai `steam add <hewan>` dulu.');
      const rem = cooldown(u, 'battle', 20000);
      if (rem) return reply(`⏳ Tunggu **${dur(rem)}** lagi.`);
      const en = D.enemies(u.level, T.units.length);
      const head = `**Team kamu:** ${unitsText(T.units)}${T.combos.length ? ` 🔗 ${T.combos.join(', ')}` : ''}\n**Musuh:** ${unitsText(en)}\n\n`;
      const r = D.simulate(T.units, en);
      const log = u.settings.log ? '```\n' + r.log.slice(-6).join('\n').slice(0, 1500) + '\n```\n' : '';
      let res;
      if (r.win) {
        const coin = rand(60, 120) + u.level * 8;
        u.coin += coin; u.stats.battleWin++; track(u, 'battle');
        res = `🏆 **Menang!** +${fmt(coin)} coin`;
        const cl = clanOf(u); if (cl) cl.points++;
        if (Math.random() < 0.1) { D.addItem(u, 'crate', 1); res += '\n🧰 Drop: 1 Crate!'; }
        else if (Math.random() < 0.03) { D.addItem(u, 'redbox', 1); res += '\n🧧 Drop: 1 Red Box!'; }
        res += addXp(u, 30);
      } else {
        u.stats.battleLose++;
        res = '💀 **Kalah...** Upgrade hewan atau pasang senjata!' + addXp(u, 8);
      }
      return reply({ embeds: [E('⚔️ Battle', head + log + res)] });
    },
  },
  {
    name: 'battlepvp', aliases: ['pvp', 'bp'], cat, desc: 'Tantang pemain lain (opsional taruhan)', usage: 'sbattlepvp @user [taruhan]',
    async run(c) {
      const { u, msg } = c;
      const { user: t, rest } = await getTarget(msg, c.args);
      if (!t || t.bot || t.id === u.id) return c.reply('Pakai: `sbattlepvp @user [taruhan]`');
      const tu = db.user(t.id);
      if (!tu.settings.pvp) return c.reply('Lawan menonaktifkan PvP.');
      const A = D.buildTeam(u), B = D.buildTeam(tu);
      if (!A.units.length) return c.reply('Teammu kosong.');
      if (!B.units.length) return c.reply('Team lawan kosong.');
      const wager = rest[0] ? parseAmt(rest[0], u.coin) : 0;
      if (rest[0] && !wager) return c.reply('Taruhan tidak valid.');
      if (wager > u.coin || wager > tu.coin) return c.reply('Coin salah satu pemain tidak cukup untuk taruhan itu.');
      if (db.busy.has(u.id) || db.busy.has(t.id)) return c.reply('Salah satu pemain masih punya game aktif.');
      db.busy.add(u.id);
      const m = await msg.reply({ content: `<@${t.id}>`, embeds: [E('🤺 Tantangan PvP', `**${msg.author.username}** menantang **${t.username}**!${wager ? `\nTaruhan: **${fmt(wager)}** coin` : ''}\nBerlaku 60 detik.`)], components: [rowOf(btn('ok', 'Terima', ButtonStyle.Success), btn('no', 'Tolak', ButtonStyle.Danger))], allowedMentions: { users: [t.id] } });
      let decided = false;
      const col = m.createMessageComponentCollector({ filter: i => i.user.id === t.id, time: 60000, max: 1 });
      col.on('collect', async i => {
        decided = true;
        if (i.customId === 'no') { db.busy.delete(u.id); return i.update({ content: '', embeds: [E('🤺 PvP', 'Tantangan ditolak.')], components: [] }); }
        const A2 = D.buildTeam(u), B2 = D.buildTeam(tu);
        const r = D.simulate(A2.units, B2.units);
        const winner = r.win ? u : tu, loser = r.win ? tu : u;
        const wName = r.win ? msg.author.username : t.username;
        let note = '';
        if (wager) {
          if ((loser.boosts.protect || 0) > Date.now()) note = '\n🛡️ Protection Card aktif — pecundang tidak kehilangan coin.';
          else { loser.coin -= wager; winner.coin += wager; note = `\n💰 ${wName} mendapat **${fmt(wager)}** coin.`; }
        }
        winner.stats.pvpWin++; loser.stats.pvpLose++;
        const xp = addXp(winner, 40);
        db.busy.delete(u.id); db.save();
        const log = (u.settings.log ? '```\n' + r.log.slice(-5).join('\n').slice(0, 1200) + '\n```\n' : '');
        await i.update({ content: '', embeds: [E('🤺 Hasil PvP', `${unitsText(A2.units)}  **VS**  ${unitsText(B2.units)}\n\n${log}🏆 Pemenang: **${wName}**${note}${xp}`)], components: [] });
      });
      col.on('end', () => { if (!decided) { db.busy.delete(u.id); m.edit({ content: '', embeds: [E('🤺 PvP', 'Tantangan kedaluwarsa.')], components: [] }).catch(() => {}); } });
    },
  },
  {
    name: 'battlesetting', aliases: ['bs'], cat, desc: 'Pengaturan battle: `sbattlesetting log on/off`, `sbattlesetting pvp on/off`', usage: 'sbattlesetting [log|pvp] [on|off]',
    async run({ u, args, reply }) {
      const k = (args[0] || '').toLowerCase(), v = (args[1] || '').toLowerCase();
      if ((k === 'log' || k === 'pvp') && (v === 'on' || v === 'off')) u.settings[k] = v === 'on';
      return reply({ embeds: [E('⚙️ Battle Setting', `📜 log (tampilkan log pertarungan): **${u.settings.log ? 'ON' : 'OFF'}**\n🤺 pvp (boleh ditantang): **${u.settings.pvp ? 'ON' : 'OFF'}**\n\nUbah: \`sbattlesetting log off\``)] });
    },
  },
  {
    name: 'clan', aliases: ['cl'], cat, desc: 'Clan: create/join/leave/info/list/deposit/kick/disband', usage: 'sclan <create|join|leave|info|list|deposit|kick|disband> ...',
    async run(c) {
      const { u, args, reply, msg } = c;
      const sub = (args[0] || 'info').toLowerCase();
      const clans = db.raw.clans;
      const mine = clanOf(u);
      if (u.clan && !mine) u.clan = null;
      if (sub === 'create') {
        const name = args.slice(1).join(' ').trim();
        if (u.clan) return reply('Kamu sudah punya clan.');
        if (name.length < 3 || name.length > 20) return reply('Nama clan 3-20 karakter.');
        if (clans[clanKey(name)]) return reply('Nama clan sudah dipakai.');
        if (u.coin < 50000) return reply('Butuh 50,000 coin untuk membuat clan.');
        u.coin -= 50000;
        clans[clanKey(name)] = { name, owner: u.id, members: [u.id], bank: 0, points: 0 };
        u.clan = name;
        return reply({ embeds: [E('🏰 Clan', `Clan **${name}** berhasil dibuat!`)] });
      }
      if (sub === 'join') {
        const cl = clans[clanKey(args.slice(1).join(' '))];
        if (u.clan) return reply('Kamu sudah punya clan.');
        if (!cl) return reply('Clan tidak ditemukan.');
        if (cl.members.length >= 20) return reply('Clan penuh (maks 20).');
        cl.members.push(u.id); u.clan = cl.name;
        return reply({ embeds: [E('🏰 Clan', `Kamu bergabung ke **${cl.name}**!`)] });
      }
      if (sub === 'leave') {
        if (!mine) return reply('Kamu tidak punya clan.');
        if (mine.owner === u.id) return reply('Owner tidak bisa keluar. Pakai `sclan disband`.');
        mine.members = mine.members.filter(x => x !== u.id); u.clan = null;
        return reply('Kamu keluar dari clan.');
      }
      if (sub === 'deposit') {
        if (!mine) return reply('Kamu tidak punya clan.');
        const n = parseAmt(args[1], u.coin);
        if (!n || n > u.coin) return reply('Jumlah tidak valid.');
        u.coin -= n; mine.bank += n;
        return reply(`Menyetor **${fmt(n)}** coin ke kas clan. Kas: ${fmt(mine.bank)}`);
      }
      if (sub === 'kick') {
        if (!mine || mine.owner !== u.id) return reply('Hanya owner clan yang bisa kick.');
        const { user: t } = await getTarget(msg, args.slice(1));
        if (!t || !mine.members.includes(t.id) || t.id === u.id) return reply('Pakai: `sclan kick @member`');
        mine.members = mine.members.filter(x => x !== t.id);
        const tu = db.user(t.id); tu.clan = null;
        return reply(`${t.username} dikeluarkan dari clan.`);
      }
      if (sub === 'disband') {
        if (!mine || mine.owner !== u.id) return reply('Hanya owner clan yang bisa membubarkan.');
        mine.members.forEach(id => { const x = db.user(id); x.clan = null; });
        u.coin += mine.bank; delete clans[clanKey(mine.name)];
        return reply('Clan dibubarkan. Kas dikembalikan ke owner.');
      }
      if (sub === 'list') {
        const top = Object.values(clans).sort((a, b) => b.points - a.points).slice(0, 10);
        return reply({ embeds: [E('🏰 Daftar Clan', top.map((x, i) => `**${i + 1}.** ${x.name} — ${x.members.length} member — ${fmt(x.points)} poin`).join('\n') || 'Belum ada clan.')] });
      }
      const cl = sub === 'info' && args[1] ? clans[clanKey(args.slice(1).join(' '))] : mine;
      if (!cl) return reply('Kamu belum punya clan. Buat dengan `sclan create <nama>` atau gabung `sclan join <nama>`.');
      const names = await Promise.all(cl.members.map(id => c.client.users.fetch(id).then(r => r.username).catch(() => id)));
      return reply({ embeds: [E(`🏰 ${cl.name}`, `👑 Owner: <@${cl.owner}>\n👥 Member (${cl.members.length}/20): ${names.join(', ')}\n🏆 Poin: **${fmt(cl.points)}** (+1 tiap menang battle)\n🪙 Kas: **${fmt(cl.bank)}**`)] });
    },
  },
];
