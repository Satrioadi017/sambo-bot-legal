const db = require('../lib/db');
const { E, fmt, rand, pick, weighted, sleep, parseBet, betError } = require('../lib/util');
const { settle, startSolo, btn, rowOf, lobby, ButtonStyle } = require('../lib/game');
const cat = 'Gamble';
const net = (bet, ret) => (ret >= bet ? `🎉 **+${fmt(ret - bet)}** coin` : `💸 **-${fmt(bet - ret)}** coin`);

// ---------- Slots ----------
const REELS = [['🍒', 28, 3], ['🍋', 24, 4], ['🍊', 20, 5], ['🍇', 14, 8], ['🔔', 8, 12], ['💎', 4, 25], ['7️⃣', 2, 50]];
const spinReel = () => weighted(REELS, r => r[1])[0];
function spin() {
  const r = [spinReel(), spinReel(), spinReel()];
  let mult = 0;
  if (r[0] === r[1] && r[1] === r[2]) mult = REELS.find(x => x[0] === r[0])[2];
  else if (r[0] === r[1] || r[1] === r[2] || r[0] === r[2]) mult = 1.5;
  return { r, mult };
}

// ---------- Klah Klok ----------
const KK = [['tiger', '🐯'], ['gourd', '🎃'], ['rooster', '🐓'], ['shrimp', '🦐'], ['crab', '🦀'], ['fish', '🐟']];
const kkRows = (prefix, dis = false) => [
  rowOf(...KK.slice(0, 3).map(([k, e]) => btn(`${prefix}${k}`, k, ButtonStyle.Primary, dis).setEmoji(e))),
  rowOf(...KK.slice(3).map(([k, e]) => btn(`${prefix}${k}`, k, ButtonStyle.Primary, dis).setEmoji(e))),
];
const kkRoll = () => [pick(KK), pick(KK), pick(KK)];
const kkEmoji = k => KK.find(x => x[0] === k)[1];

// ---------- Mines ----------
const T = 20;
function minesMult(safe, mines) {
  let m = 0.97;
  for (let i = 0; i < safe; i++) m *= (T - i) / (T - mines - i);
  return m;
}

// ---------- Fishing ----------
const FISH = [['🥾 Sepatu bekas', 0, 33], ['🌿 Rumput laut', 0.5, 17], ['🐟 Ikan', 1, 25], ['🐠 Ikan hias', 1.4, 15], ['🐡 Ikan buntal', 3, 7], ['🦈 Hiu', 4, 3], ['💰 Peti harta', 8, 1]];

module.exports = [
  {
    name: 'coinflip', aliases: ['cf'], cat, desc: 'Lempar koin. `scoinflip <taruhan> [h|t]`', usage: 'scoinflip <taruhan> [h|t]',
    async run(c) {
      const side = /^t/i.test(c.args.find(a => /^(h|t)/i.test(a)) || '') ? 'tails' : 'heads';
      const betArg = c.args.find(a => !/^(h|t)/i.test(a));
      const s = await startSolo(c, betArg);
      if (!s) return;
      const flip = Math.random() < 0.5 ? 'heads' : 'tails';
      const ret = flip === side ? s.bet * 2 : 0;
      settle(c.u, s.bet, ret); s.rel();
      return c.reply({ embeds: [E('🪙 Coinflip', `Pilihan: **${side}**\nHasil: **${flip}**\n${net(s.bet, ret)}\nSaldo: ${fmt(c.u.coin)}`)] });
    },
  },
  {
    name: 'slots', aliases: ['slot', 's', 'sl'], cat, desc: 'Mesin slot', usage: 'sslots <taruhan>',
    async run(c) {
      const s = await startSolo(c);
      if (!s) return;
      const { r, mult } = spin();
      const ret = Math.floor(s.bet * mult);
      settle(c.u, s.bet, ret); s.rel();
      return c.reply({ embeds: [E('🎰 Slots', `**[ ${r.join(' | ')} ]**\n${mult ? `Multiplier x${mult}` : 'Tidak cocok'}\n${net(s.bet, ret)}\nSaldo: ${fmt(c.u.coin)}`)] });
    },
  },
  {
    name: 'slotsmultiplayer', aliases: ['slotsmp', 'smp'], cat, desc: 'Slots bareng pemain lain (lobby 30 detik)', usage: 'sslotsmultiplayer <taruhan>',
    async run(c) {
      const bet = parseBet(c.args[0], c.u); const err = betError(c.u, bet);
      if (err) return c.reply(err);
      if (db.busy.has(c.u.id)) return c.reply('Kamu masih punya game aktif.');
      const L = await lobby(c, { title: '🎰 Slots Multiplayer', bet });
      if (!L) return;
      const lines = L.list.map(p => {
        const { r, mult } = spin(); const ret = Math.floor(bet * mult);
        settle(p.u, bet, ret);
        return `**${p.name}** [ ${r.join(' | ')} ] ${mult ? `x${mult}` : ''} ${net(bet, ret)}`;
      });
      L.release();
      return c.msg.channel.send({ embeds: [E('🎰 Hasil Slots Multiplayer', lines.join('\n'))] });
    },
  },
  {
    name: 'fishing', aliases: ['fish', 'f'], cat, desc: 'Memancing (taruhan = umpan)', usage: 'sfishing <taruhan>',
    async run(c) {
      const s = await startSolo(c);
      if (!s) return;
      const m = await c.reply({ embeds: [E('🎣 Fishing', 'Kamu melempar kail… 🌊')] });
      await sleep(1800);
      const f = weighted(FISH, x => x[2]);
      const ret = Math.floor(s.bet * f[1]);
      settle(c.u, s.bet, ret); s.rel();
      return m.edit({ embeds: [E('🎣 Fishing', `Kamu mendapat **${f[0]}**!\n${f[1] ? `Nilai x${f[1]}` : 'Tidak bernilai'}\n${net(s.bet, ret)}\nSaldo: ${fmt(c.u.coin)}`)] }).catch(() => {});
    },
  },
  {
    name: 'amongus', aliases: ['au', 'impostor'], cat, desc: 'Tebak siapa impostor (menang x4.5)', usage: 'samongus <taruhan>',
    async run(c) {
      const s = await startSolo(c);
      if (!s) return;
      const crew = [['red', '🔴'], ['blue', '🔵'], ['green', '🟢'], ['yellow', '🟡'], ['purple', '🟣']];
      const imp = pick(crew)[0];
      const row = dis => rowOf(...crew.map(([k, e]) => btn(k, k, ButtonStyle.Secondary, dis).setEmoji(e)));
      const m = await c.reply({ embeds: [E('🚀 Among Us', 'Ada **1 impostor** di antara kru! Siapa dia? (30 detik)\n\n' + crew.map(x => x[1]).join('  '))], components: [row(false)] });
      let done = false;
      const end = async (choice, i) => {
        if (done) return; done = true;
        const win = choice === imp;
        const ret = win ? Math.floor(s.bet * 4.5) : 0;
        settle(c.u, s.bet, ret); s.rel();
        const e = E('🚀 Among Us', `Pilihanmu: **${choice || '-'}**\nImpostornya: **${imp}** ${crew.find(x => x[0] === imp)[1]}\n${win ? '🎉 Kamu benar!' : '💀 Salah!'} ${net(s.bet, ret)}`);
        if (i) await i.update({ embeds: [e], components: [] }); else await m.edit({ embeds: [e], components: [] }).catch(() => {});
      };
      const col = m.createMessageComponentCollector({ filter: i => i.user.id === c.u.id, time: 30000 });
      col.on('collect', i => { col.stop(); end(i.customId, i).catch(console.error); });
      col.on('end', () => { if (!done) end(null, null).catch(() => {}); });
    },
  },
  {
    name: 'klahklok', aliases: ['kk'], cat, desc: 'Dadu Khmer: pilih hewan, 3 dadu dilempar', usage: 'sklahklok <taruhan>',
    async run(c) {
      const s = await startSolo(c);
      if (!s) return;
      const m = await c.reply({ embeds: [E('🎲 Klah Klok', 'Pilih simbol! Tiap dadu yang cocok membayar **1× taruhan** (maks 3×).')], components: kkRows('k_') });
      let done = false;
      const finish = async (key, i) => {
        if (done) return; done = true;
        const dice = kkRoll();
        const hit = key ? dice.filter(d => d[0] === key).length : 0;
        const ret = hit ? s.bet * (1 + hit) : 0;
        settle(c.u, s.bet, ret); s.rel();
        const e = E('🎲 Klah Klok', `Pilihanmu: ${key ? kkEmoji(key) : '-'}\nDadu: **${dice.map(d => d[1]).join(' ')}**\nCocok: **${hit}**\n${net(s.bet, ret)}`);
        if (i) await i.update({ embeds: [e], components: [] }); else await m.edit({ embeds: [e], components: [] }).catch(() => {});
      };
      const col = m.createMessageComponentCollector({ filter: i => i.user.id === c.u.id, time: 30000 });
      col.on('collect', i => { col.stop(); finish(i.customId.slice(2), i).catch(console.error); });
      col.on('end', () => { if (!done) finish(null, null).catch(() => {}); });
    },
  },
  {
    name: 'klahklokmultiplayer', aliases: ['kkmp'], cat, desc: 'Klah Klok bareng: klik simbol untuk ikut (30 detik)', usage: 'sklahklokmultiplayer <taruhan>',
    async run(c) {
      const bet = parseBet(c.args[0], c.u); const err = betError(c.u, bet);
      if (err) return c.reply(err);
      if (db.busy.has(c.u.id)) return c.reply('Kamu masih punya game aktif.');
      const players = new Map(); // id -> {u,name,key}
      const join = (user, key) => {
        if (players.has(user.id)) { players.get(user.id).key = key; return; }
        const pu = db.user(user.id); pu.coin -= bet; db.busy.add(user.id);
        players.set(user.id, { id: user.id, u: pu, name: user.username, key });
      };
      join(c.msg.author, null); players.get(c.u.id).key = null;
      const view = () => E('🎲 Klah Klok Multiplayer', `Taruhan: **${fmt(bet)}** coin. Klik simbol untuk bergabung/ganti pilihan. Dadu dilempar dalam 30 detik.\n\n${[...players.values()].map(p => `• ${p.name}: ${p.key ? kkEmoji(p.key) : '❔'}`).join('\n')}`);
      const m = await c.reply({ embeds: [view()], components: kkRows('m_') });
      await new Promise(res => {
        const col = m.createMessageComponentCollector({ time: 30000 });
        col.on('collect', async i => {
          try {
            if (!players.has(i.user.id)) {
              if (db.busy.has(i.user.id)) return i.reply({ content: 'Kamu masih punya game aktif.', ephemeral: true });
              if (db.user(i.user.id).coin < bet) return i.reply({ content: 'Coin tidak cukup.', ephemeral: true });
              if (players.size >= 10) return i.reply({ content: 'Penuh.', ephemeral: true });
            }
            join(i.user, i.customId.slice(2));
            await i.update({ embeds: [view()] });
          } catch (e) { console.error(e); }
        });
        col.on('end', () => res());
      });
      const dice = kkRoll();
      const lines = [...players.values()].map(p => {
        const hit = p.key ? dice.filter(d => d[0] === p.key).length : 0;
        const ret = hit ? bet * (1 + hit) : 0;
        settle(p.u, bet, ret); db.busy.delete(p.id);
        return `**${p.name}** ${p.key ? kkEmoji(p.key) : '❔'} → ${hit} cocok ${net(bet, ret)}`;
      });
      await m.edit({ components: kkRows('m_', true) }).catch(() => {});
      return c.msg.channel.send({ embeds: [E('🎲 Hasil Klah Klok', `Dadu: **${dice.map(d => d[1]).join(' ')}**\n\n${lines.join('\n')}`)] });
    },
  },
  {
    name: 'mines', aliases: ['mine', 'm'], cat, desc: 'Buka kotak aman, hindari bom. `smines <taruhan> [jumlah bom 1-10]`', usage: 'smines <taruhan> [bom]',
    async run(c) {
      const mines = Math.min(10, Math.max(1, parseInt(c.args[1], 10) || 3));
      const s = await startSolo(c);
      if (!s) return;
      const bombs = new Set();
      while (bombs.size < mines) bombs.add(rand(0, T - 1));
      const opened = new Set();
      let over = false;
      const build = (reveal = false) => {
        const rows = [];
        for (let r = 0; r < 4; r++) {
          const row = rowOf();
          for (let k = 0; k < 5; k++) {
            const idx = r * 5 + k;
            let b = btn(`t${idx}`, '\u200b', ButtonStyle.Secondary, over);
            if (opened.has(idx)) b = btn(`t${idx}`, '\u200b', ButtonStyle.Success, true).setEmoji('💎');
            else if (reveal && bombs.has(idx)) b = btn(`t${idx}`, '\u200b', ButtonStyle.Danger, true).setEmoji('💣');
            row.addComponents(b);
          }
          rows.push(row);
        }
        const cur = minesMult(opened.size, mines);
        rows.push(rowOf(btn('cash', `Cashout x${cur.toFixed(2)} (${fmt(s.bet * cur)})`, ButtonStyle.Primary, over || opened.size === 0)));
        return rows;
      };
      const info = (extra = '') => E('💣 Mines', `Taruhan: **${fmt(s.bet)}** | Bom: **${mines}** | Aman: **${opened.size}/${T - mines}**\nSaat ini: **x${minesMult(opened.size, mines).toFixed(2)}** | Berikutnya: **x${minesMult(opened.size + 1, mines).toFixed(2)}**${extra}`);
      const m = await c.reply({ embeds: [info()], components: build() });
      const col = m.createMessageComponentCollector({ filter: i => i.user.id === c.u.id, time: 120000 });
      const cashout = async i => {
        over = true; col.stop('done');
        const ret = Math.floor(s.bet * minesMult(opened.size, mines));
        settle(c.u, s.bet, ret); s.rel();
        const e = info(`\n✅ Cashout! ${net(s.bet, ret)}`);
        if (i) await i.update({ embeds: [e], components: build(true) }); else await m.edit({ embeds: [e], components: build(true) }).catch(() => {});
      };
      col.on('collect', async i => {
        try {
          if (over) return;
          if (i.customId === 'cash') return await cashout(i);
          const idx = parseInt(i.customId.slice(1), 10);
          if (bombs.has(idx)) {
            over = true; col.stop('done');
            settle(c.u, s.bet, 0); s.rel();
            opened.delete(idx);
            return await i.update({ embeds: [info(`\n💥 Kena bom! ${net(s.bet, 0)}`)], components: build(true) });
          }
          opened.add(idx);
          if (opened.size === T - mines) return await cashout(i);
          await i.update({ embeds: [info()], components: build() });
        } catch (e) { console.error(e); }
      });
      col.on('end', (_, reason) => { if (reason !== 'done' && !over) { if (opened.size) cashout(null).catch(() => {}); else { over = true; settle(c.u, s.bet, s.bet); s.rel(); m.edit({ embeds: [E('💣 Mines', 'Waktu habis, taruhan dikembalikan.')], components: [] }).catch(() => {}); } } });
    },
  },
];
