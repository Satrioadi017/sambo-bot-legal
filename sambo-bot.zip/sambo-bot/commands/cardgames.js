const db = require('../lib/db');
const C = require('../lib/cards');
const { E, fmt, parseBet, betError } = require('../lib/util');
const { settle, startSolo, btn, rowOf, lobby, ButtonStyle } = require('../lib/game');
const cat = 'Gamble';
const net = (bet, ret) => (ret >= bet ? `🎉 **+${fmt(ret - bet)}** coin` : `💸 **-${fmt(bet - ret)}** coin`);
const hitRow = (dis = false) => rowOf(btn('hit', 'Hit', ButtonStyle.Primary, dis), btn('stand', 'Stand', ButtonStyle.Secondary, dis));
const drawRow = (dis = false) => rowOf(btn('draw', 'Tarik kartu', ButtonStyle.Primary, dis), btn('stay', 'Cukup', ButtonStyle.Secondary, dis));

function bjResult(p, dl, bet) {
  const pv = C.bjv(p), dv = C.bjv(dl);
  if (pv > 21) return { text: 'Bust! Kamu kalah.', ret: 0 };
  if (dv > 21 || pv > dv) return { text: 'Kamu menang!', ret: bet * 2 };
  if (pv === dv) return { text: 'Seri.', ret: bet };
  return { text: 'Dealer menang.', ret: 0 };
}
const pokPay = (cmp, bet, u) => {
  if (cmp.res === 'win') return bet * (1 + cmp.mult);
  if (cmp.res === 'push') return bet;
  return -Math.min(bet * (cmp.mult - 1), u.coin); // pembayaran deng ekstra, dibatasi saldo
};
const pokNote = cmp => (cmp.res === 'push' ? 'Seri' : `${cmp.res === 'win' ? 'Menang' : 'Kalah'}${cmp.mult > 1 ? ` (${cmp.mult} deng)` : ''}`);

module.exports = [
  {
    name: 'blackjack', aliases: ['bj'], cat, desc: 'Blackjack lawan dealer', usage: 'sblackjack <taruhan>',
    async run(c) {
      const s = await startSolo(c);
      if (!s) return;
      const { u } = c, bet = s.bet;
      const d = C.deck();
      const p = [d.pop(), d.pop()], dl = [d.pop(), d.pop()];
      let done = false;
      const view = (reveal, text = '', ret = 0) => E('🃏 Blackjack',
        `**Kamu** (${C.bjv(p)}): ${C.hand(p)}\n**Dealer** (${reveal ? C.bjv(dl) : '?'}): ${reveal ? C.hand(dl) : C.label(dl[0]) + ' 🂠'}\n${text ? `\n**${text}** ${net(bet, ret)}\nSaldo: ${fmt(u.coin)}` : ''}`);
      if (C.bjv(p) === 21) {
        const ret = C.bjv(dl) === 21 ? bet : Math.floor(bet * 2.5);
        settle(u, bet, ret); s.rel();
        return c.reply({ embeds: [view(true, ret === bet ? 'Seri, sama-sama Blackjack.' : 'BLACKJACK! (3:2)', ret)] });
      }
      const m = await c.reply({ embeds: [view(false)], components: [hitRow()] });
      const col = m.createMessageComponentCollector({ filter: i => i.user.id === u.id, time: 60000 });
      const finish = async i => {
        if (done) return; done = true; col.stop();
        while (C.bjv(dl) < 17) dl.push(d.pop());
        const r = bjResult(p, dl, bet);
        settle(u, bet, r.ret); s.rel();
        const e = view(true, r.text, r.ret);
        if (i) await i.update({ embeds: [e], components: [] }); else await m.edit({ embeds: [e], components: [] }).catch(() => {});
      };
      col.on('collect', async i => {
        try {
          if (done) return;
          if (i.customId === 'hit') { p.push(d.pop()); if (C.bjv(p) >= 21) return await finish(i); return await i.update({ embeds: [view(false)], components: [hitRow()] }); }
          await finish(i);
        } catch (e) { console.error(e); }
      });
      col.on('end', () => { if (!done) finish(null).catch(() => {}); });
    },
  },
  {
    name: 'blackjackmultiplayer', aliases: ['bjmp'], cat, desc: 'Blackjack bareng pemain lain (lobby 30 detik)', usage: 'sblackjackmultiplayer <taruhan>',
    async run(c) {
      const bet = parseBet(c.args[0], c.u); const err = betError(c.u, bet);
      if (err) return c.reply(err);
      if (db.busy.has(c.u.id)) return c.reply('Kamu masih punya game aktif.');
      const L = await lobby(c, { title: '🃏 Blackjack Multiplayer', bet, min: 1, max: 6 });
      if (!L) return;
      try {
        const d = C.deck();
        const dl = [d.pop(), d.pop()];
        L.list.forEach(p => { p.hand = [d.pop(), d.pop()]; });
        const table = (turn, reveal = false) => E('🃏 Blackjack Multiplayer',
          `**Dealer**: ${reveal ? `${C.hand(dl)} (${C.bjv(dl)})` : C.label(dl[0]) + ' 🂠'}\n\n` +
          L.list.map(p => `${turn && turn.id === p.id ? '👉 ' : ''}**${p.name}**: ${C.hand(p.hand)} (${C.bjv(p.hand)})${C.bjv(p.hand) > 21 ? ' 💥' : ''}`).join('\n') + (turn ? `\n\nGiliran **${turn.name}** (30 detik)` : ''));
        const m = await c.msg.channel.send({ embeds: [table(L.list[0])] });
        for (const p of L.list) {
          if (C.bjv(p.hand) >= 21) continue;
          await m.edit({ embeds: [table(p)], components: [hitRow()] });
          await new Promise(res => {
            const col = m.createMessageComponentCollector({ filter: i => i.user.id === p.id, time: 30000 });
            col.on('collect', async i => {
              try {
                if (i.customId === 'hit') {
                  p.hand.push(d.pop());
                  if (C.bjv(p.hand) >= 21) { await i.deferUpdate(); return col.stop(); }
                  return await i.update({ embeds: [table(p)], components: [hitRow()] });
                }
                await i.deferUpdate(); col.stop();
              } catch (e) { console.error(e); }
            });
            col.on('end', () => res());
          });
        }
        while (C.bjv(dl) < 17) dl.push(d.pop());
        const lines = L.list.map(p => {
          const nat = C.bjv(p.hand) === 21 && p.hand.length === 2;
          const r = bjResult(p.hand, dl, bet);
          const ret = nat && C.bjv(dl) !== 21 ? Math.floor(bet * 2.5) : r.ret;
          settle(p.u, bet, ret);
          return `**${p.name}** — ${nat ? 'Blackjack!' : r.text} ${net(bet, ret)}`;
        });
        await m.edit({ embeds: [E('🃏 Hasil Blackjack', `${table(null, true).data.description}\n\n${lines.join('\n')}`)], components: [] });
      } finally { L.release(); }
    },
  },
  {
    name: 'pokkdeang', aliases: ['pokdeng', 'pd'], cat, desc: 'Pok Deng (kartu Thailand/Khmer) lawan dealer', usage: 'spokkdeang <taruhan>',
    async run(c) {
      const s = await startSolo(c);
      if (!s) return;
      const { u } = c, bet = s.bet;
      const d = C.deck();
      const p = [d.pop(), d.pop()], dl = [d.pop(), d.pop()];
      let done = false;
      const view = (reveal, text = '') => E('🎴 Pok Deng',
        `**Kamu** (${C.pts(p)} poin${C.isPok(p) ? ' POK!' : ''}): ${C.hand(p)}\n**Dealer**: ${reveal ? `${C.hand(dl)} (${C.pts(dl)} poin${C.isPok(dl) ? ' POK!' : ''})` : '🂠 🂠'}\n${text}`);
      const finish = async (i, first = false) => {
        if (done) return; done = true;
        if (!C.isPok(p) && !C.isPok(dl)) while (C.pts(dl) <= 4 && dl.length < 3) dl.push(d.pop());
        const cmp = C.pokCompare(p, dl);
        const ret = pokPay(cmp, bet, u);
        settle(u, bet, ret); s.rel();
        const e = view(true, `\n**${pokNote(cmp)}** ${net(bet, ret)}\nSaldo: ${fmt(u.coin)}`);
        if (i) await i.update({ embeds: [e], components: [] }); else if (first) await c.reply({ embeds: [e] }); else await c.msg.channel.send({ embeds: [e] }).catch(() => {});
      };
      if (C.isPok(p) || C.isPok(dl)) return finish(null, true);
      const m = await c.reply({ embeds: [view(false, 'Tarik kartu ketiga atau cukup?')], components: [drawRow()] });
      const col = m.createMessageComponentCollector({ filter: i => i.user.id === u.id, time: 40000 });
      col.on('collect', async i => {
        try {
          if (done) return; col.stop('x');
          if (i.customId === 'draw') p.push(d.pop());
          await finish(i);
        } catch (e) { console.error(e); }
      });
      col.on('end', (_, r) => { if (!done && r !== 'x') { finish(null).then(() => m.edit({ components: [] }).catch(() => {})).catch(() => {}); } });
    },
  },
  {
    name: 'pokkdeangmultiplayer', aliases: ['pokdengmp', 'pdmp'], cat, desc: 'Pok Deng bareng pemain lain (semua lawan dealer bot)', usage: 'spokkdeangmultiplayer <taruhan>',
    async run(c) {
      const bet = parseBet(c.args[0], c.u); const err = betError(c.u, bet);
      if (err) return c.reply(err);
      if (db.busy.has(c.u.id)) return c.reply('Kamu masih punya game aktif.');
      const L = await lobby(c, { title: '🎴 Pok Deng Multiplayer', bet, min: 1, max: 8 });
      if (!L) return;
      try {
        const d = C.deck();
        const dl = [d.pop(), d.pop()];
        L.list.forEach(p => { p.hand = [d.pop(), d.pop()]; if (!C.isPok(p.hand) && C.pts(p.hand) < 5) p.hand.push(d.pop()); });
        if (!C.isPok(dl) && C.pts(dl) <= 4) dl.push(d.pop());
        const lines = L.list.map(p => {
          const cmp = C.pokCompare(p.hand, dl);
          const ret = pokPay(cmp, bet, p.u);
          settle(p.u, bet, ret);
          return `**${p.name}**: ${C.hand(p.hand)} (${C.pts(p.hand)}) — ${pokNote(cmp)} ${net(bet, ret)}`;
        });
        await c.msg.channel.send({ embeds: [E('🎴 Hasil Pok Deng', `**Dealer**: ${C.hand(dl)} (${C.pts(dl)})\n\n${lines.join('\n')}\n\n_Pemain otomatis menarik kartu jika poin < 5._`)] });
      } finally { L.release(); }
    },
  },
];
