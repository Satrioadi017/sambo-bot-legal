const db = require('../lib/db');
const D = require('../lib/data');
const { E, fmt, cap, dur, cooldown, rand, addXp, track, parseAmt } = require('../lib/util');
const { RAR, ANIMALS } = D;
const cat = 'Hunt';

function doHunt(u, times = 1) {
  const luck = (u.boosts.animals || 0) > Date.now() ? 2 : 1;
  const found = {};
  for (let i = 0; i < times; i++) {
    const n = rand(1, 3);
    for (let j = 0; j < n; j++) { const a = D.rollAnimal(0, luck); D.addAnimal(u, a.id, 1); found[a.id] = (found[a.id] || 0) + 1; }
  }
  return found;
}
const foundText = f => Object.entries(f).sort((a, b) => ANIMALS[b[0]].ri - ANIMALS[a[0]].ri)
  .map(([id, n]) => `${RAR[ANIMALS[id].ri].e} ${ANIMALS[id].emoji} ${cap(id)} ×${n}`).join('\n') || '-';

function collectAuto(u) {
  const a = u.autohunt;
  if (!a) return null;
  const now = Date.now();
  const end = Math.min(now, a.until);
  const n = Math.min(300, Math.floor((end - a.last) / 300000));
  let found = {};
  if (n > 0) { found = doHunt(u, n); a.last += n * 300000; u.stats.hunts += n; track(u, 'hunt', n); }
  const finished = now >= a.until;
  if (finished) u.autohunt = null;
  return { n, found, finished };
}

// cari target jual/sacrifice
function pickList(u, args) {
  const t = (args[0] || '').toLowerCase();
  const avail = id => Math.max(0, (u.animals[id] || 0) - (u.team.includes(id) ? 1 : 0));
  const res = [];
  if (t === 'all') { for (const id in u.animals) { const n = avail(id); if (n) res.push([id, n]); } return res; }
  const ri = RAR.findIndex(r => r.k === t || r.n.toLowerCase() === t);
  if (ri >= 0) { for (const id in u.animals) if (ANIMALS[id] && ANIMALS[id].ri === ri) { const n = avail(id); if (n) res.push([id, n]); } return res; }
  const a = D.findAnimal(t);
  if (!a) return null;
  let n = avail(a.id);
  const amt = args[1];
  if (amt && amt.toLowerCase() !== 'all') { const x = parseInt(amt, 10); if (!(x > 0)) return null; n = Math.min(n, x); }
  if (n) res.push([a.id, n]);
  return res;
}
function consume(u, list, key) {
  let total = 0, cnt = 0;
  for (const [id, n] of list) {
    u.animals[id] -= n; if (u.animals[id] <= 0) delete u.animals[id];
    total += n * RAR[ANIMALS[id].ri][key]; cnt += n;
  }
  return { total, cnt };
}

const SHOP = {
  lootbox: { price: 500, give: u => D.addItem(u, 'lootbox', 1), name: '📦 Lootbox' },
  uwubox: { price: 2500, give: u => D.addItem(u, 'uwubox', 1), name: '🎁 Uwu Box' },
  crate: { price: 3000, give: u => D.addItem(u, 'crate', 1), name: '🧰 Crate' },
  protectioncard: { price: 10000, give: u => D.addItem(u, 'protectioncard', 1), name: '🛡️ Protection Card' },
  ticket: { price: 5000, give: u => { u.ticket += 1; }, name: '🎫 Ticket' },
};

module.exports = [
  {
    name: 'hunt', aliases: ['h'], cat, desc: 'Berburu hewan (biaya 10 coin, cooldown 15 detik)', usage: 'shunt',
    async run({ u, reply }) {
      if (u.coin < 10) return reply('Butuh 10 coin untuk berburu.');
      const rem = cooldown(u, 'hunt', 15000);
      if (rem) return reply(`⏳ Tunggu **${dur(rem)}** lagi untuk berburu.`);
      u.coin -= 10;
      const f = doHunt(u, 1);
      u.stats.hunts++; track(u, 'hunt');
      const boost = (u.boosts.animals || 0) > Date.now() ? '\n🍀 Boost hewan aktif' : '';
      return reply({ embeds: [E('🏹 Hunt', foundText(f) + boost + addXp(u, 5), { footer: '-10 coin' })] });
    },
  },
  {
    name: 'autohunt', aliases: ['ah'], cat, desc: 'Autohunt (400 coin/jam). `sautohunt <jam>` beli, `sautohunt` klaim', usage: 'sautohunt [jam]',
    async run({ u, args, reply }) {
      const hours = parseInt(args[0], 10);
      if (hours > 0) {
        if (hours > 24) return reply('Maksimal 24 jam.');
        const cost = hours * 400;
        if (u.coin < cost) return reply(`Butuh ${fmt(cost)} coin.`);
        const pre = collectAuto(u);
        u.coin -= cost;
        const now = Date.now();
        u.autohunt = { until: (u.autohunt ? u.autohunt.until : now) + hours * 36e5, last: u.autohunt ? u.autohunt.last : now };
        return reply({ embeds: [E('🤖 Autohunt', `Autohunt aktif **${hours} jam** (-${fmt(cost)} coin).\nBot berburu otomatis tiap 5 menit. Klaim dengan \`sautohunt\`.${pre && pre.n ? `\n\nHasil sebelumnya:\n${foundText(pre.found)}` : ''}`)] });
      }
      if (!u.autohunt) return reply('Autohunt tidak aktif. Beli dengan `sautohunt <jam>`.');
      const r = collectAuto(u);
      const left = u.autohunt ? `\n⏱️ Sisa: ${dur(u.autohunt.until - Date.now())}` : '\n✅ Autohunt selesai.';
      return reply({ embeds: [E('🤖 Autohunt', r.n ? `**${r.n}** hunt otomatis:\n${foundText(r.found)}${left}` : `Belum ada hasil baru.${left}`)] });
    },
  },
  {
    name: 'boostanimals', aliases: ['ba'], cat, desc: 'Boost keberuntungan hewan langka x2 selama 1 jam (1,500 coin)', usage: 'sboostanimals',
    async run({ u, reply }) {
      if (u.coin < 1500) return reply('Butuh 1,500 coin.');
      u.coin -= 1500;
      u.boosts.animals = Math.max(Date.now(), u.boosts.animals || 0) + 36e5;
      return reply({ embeds: [E('🍀 Boost Animals', `Peluang hewan Rare+ x2 selama **${dur(u.boosts.animals - Date.now())}**.`)] });
    },
  },
  {
    name: 'dex', aliases: ['pokedex'], cat, desc: 'Koleksi hewan yang pernah kamu dapat', usage: 'sdex',
    async run({ u, reply }) {
      let total = 0, got = 0;
      const lines = RAR.map((r, ri) => {
        const list = D.ANIMAL_LIST.filter(a => a.ri === ri);
        const have = list.filter(a => u.dex[a.id]);
        total += list.length; got += have.length;
        return `${r.e} **${r.n}** (${have.length}/${list.length})\n${list.map(a => (u.dex[a.id] ? a.emoji : '❓')).join(' ')}`;
      });
      return reply({ embeds: [E(`📖 Dex (${got}/${total})`, lines.join('\n\n'))] });
    },
  },
  {
    name: 'finishhunt', aliases: ['fh'], cat, desc: 'Reset cooldown hunt (50 coin) & klaim autohunt', usage: 'sfinishhunt',
    async run({ u, reply }) {
      let out = '';
      if (u.cd.hunt && Date.now() - u.cd.hunt < 15000) {
        if (u.coin < 50) return reply('Butuh 50 coin untuk reset cooldown.');
        u.coin -= 50; u.cd.hunt = 0; out += '⚡ Cooldown hunt direset (-50 coin).\n';
      }
      const r = collectAuto(u);
      if (r && r.n) out += `🤖 Hasil autohunt (${r.n}x):\n${foundText(r.found)}`;
      return reply({ embeds: [E('🏁 Finish Hunt', out || 'Tidak ada yang perlu diselesaikan.')] });
    },
  },
  {
    name: 'sacrifice', aliases: ['sac'], cat, desc: 'Korbankan hewan jadi point (untuk upgrade)', usage: 'ssacrifice <hewan|rarity|all> [jumlah]',
    async run({ u, args, reply }) {
      const list = pickList(u, args);
      if (!list) return reply('Pakai: `ssacrifice <hewan|rarity|all> [jumlah]`');
      if (!list.length) return reply('Tidak ada hewan yang bisa dikorbankan (hewan di team disisakan 1).');
      const { total, cnt } = consume(u, list, 'sac');
      u.point += total;
      return reply({ embeds: [E('🔥 Sacrifice', `Mengorbankan **${cnt}** hewan → **+${fmt(total)}** point ✨`)] });
    },
  },
  {
    name: 'sell', cat, desc: 'Jual hewan jadi coin', usage: 'ssell <hewan|rarity|all> [jumlah]',
    async run({ u, args, reply }) {
      const list = pickList(u, args);
      if (!list) return reply('Pakai: `ssell <hewan|rarity|all> [jumlah]`');
      if (!list.length) return reply('Tidak ada hewan yang bisa dijual (hewan di team disisakan 1).');
      const { total, cnt } = consume(u, list, 'sell');
      u.coin += total;
      return reply({ embeds: [E('💰 Sell', `Menjual **${cnt}** hewan → **+${fmt(total)}** coin`)] });
    },
  },
  {
    name: 'team', aliases: ['t'], cat, desc: 'Atur team battle (maks 3). `steam add <hewan>`, `steam remove <hewan>`', usage: 'steam [add|remove] <hewan>',
    async run({ u, args, reply }) {
      const sub = (args[0] || '').toLowerCase();
      if (sub === 'add') {
        const a = D.findAnimal(args[1]);
        if (!a || !u.animals[a.id]) return reply('Kamu tidak punya hewan itu.');
        if (u.team.includes(a.id)) return reply('Hewan itu sudah ada di team.');
        if (u.team.length >= 3) return reply('Team penuh (maks 3). Hapus dulu dengan `steam remove <hewan>`.');
        u.team.push(a.id);
      } else if (sub === 'remove' || sub === 'rm') {
        const a = D.findAnimal(args[1]);
        if (!a || !u.team.includes(a.id)) return reply('Hewan itu tidak ada di team.');
        u.team = u.team.filter(x => x !== a.id);
        u.weapons.forEach(w => { if (w.animal === a.id) w.animal = null; });
      }
      const T = D.buildTeam(u);
      const lines = u.team.map((id, i) => {
        const a = ANIMALS[id]; const w = u.weapons.find(x => x.animal === id);
        return `**${i + 1}.** ${RAR[a.ri].e} ${a.emoji} ${cap(a.name)} (Lv ${u.animalLevels[id] || 1})${w ? ' ' + D.weaponLine(w) : ''}`;
      });
      const units = T.units.map(x => `${x.emoji} ATK ${fmt(x.atk)} / HP ${fmt(x.hp)}`).join('\n');
      return reply({ embeds: [E('🛡️ Team', (lines.join('\n') || 'Team kosong. Tambah dengan `steam add <hewan>`.') + (units ? `\n\n${units}` : '') + (T.combos.length ? `\n🔗 Combo: ${T.combos.join(', ')}` : ''))] });
    },
  },
  {
    name: 'upgrade', aliases: ['up'], cat, desc: 'Upgrade level hewan pakai point (maks Lv 10)', usage: 'supgrade <hewan>',
    async run({ u, args, reply }) {
      const a = D.findAnimal(args[0]);
      if (!a || !u.animals[a.id]) return reply('Pakai: `supgrade <hewan>` (hewan harus kamu miliki).');
      const lvl = u.animalLevels[a.id] || 1;
      if (lvl >= 10) return reply('Hewan ini sudah level maksimal (10).');
      const cost = lvl * 10 * (a.ri + 1);
      if (u.point < cost) return reply(`Butuh **${fmt(cost)}** point ✨ (kamu punya ${fmt(u.point)}). Dapatkan lewat \`ssacrifice\`.`);
      u.point -= cost; u.animalLevels[a.id] = lvl + 1;
      return reply({ embeds: [E('⬆️ Upgrade', `${a.emoji} ${cap(a.name)} naik ke **Level ${lvl + 1}** (-${fmt(cost)} point)`)] });
    },
  },
  {
    name: 'zoo', aliases: ['z'], cat, desc: 'Lihat koleksi hewan kamu', usage: 'szoo',
    async run({ u, reply, msg }) {
      let total = 0;
      const lines = [];
      for (let ri = RAR.length - 1; ri >= 0; ri--) {
        const items = D.ANIMAL_LIST.filter(a => a.ri === ri && u.animals[a.id] > 0);
        if (!items.length) continue;
        total += items.reduce((s, a) => s + u.animals[a.id], 0);
        lines.push(`${RAR[ri].e} **${RAR[ri].n}**\n${items.map(a => `${a.emoji}×${u.animals[a.id]}`).join('  ')}`);
      }
      return reply({ embeds: [E(`🦁 Zoo ${msg.author.username} (${fmt(total)} hewan)`, lines.join('\n\n') || 'Zoo kosong. Mulai dengan `shunt`!')] });
    },
  },
  {
    name: 'zooshop', aliases: ['shop'], cat, desc: 'Toko: `szooshop buy <item> [jumlah]`', usage: 'szooshop [buy <item> [jumlah]]',
    async run({ u, args, reply }) {
      if ((args[0] || '').toLowerCase() === 'buy') {
        const k = (args[1] || '').toLowerCase(); const it = SHOP[k];
        if (!it) return reply('Item tidak ada. Lihat daftar dengan `szooshop`.');
        const n = args[2] ? parseAmt(args[2], Math.floor(u.coin / it.price)) : 1;
        if (!n || n > 1000) return reply('Jumlah tidak valid.');
        const cost = n * it.price;
        if (u.coin < cost) return reply(`Butuh ${fmt(cost)} coin.`);
        u.coin -= cost; for (let i = 0; i < n; i++) it.give(u);
        return reply({ embeds: [E('🛒 Zoo Shop', `Membeli **${n}× ${it.name}** seharga **${fmt(cost)}** coin.`)] });
      }
      return reply({ embeds: [E('🛒 Zoo Shop', Object.entries(SHOP).map(([k, v]) => `${v.name} — \`${k}\` — **${fmt(v.price)}** coin`).join('\n') + '\n\nBeli: `szooshop buy <item> [jumlah]`')] });
    },
  },
];
