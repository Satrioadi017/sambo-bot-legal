const D = require('../lib/data');
const { E, fmt, cap, parseAmt } = require('../lib/util');
const { RAR, ANIMALS, WTYPES } = D;
const cat = 'Weapons';

function crateCmd(key, aliases = []) {
  const info = D.CRATES[key];
  return {
    name: key, aliases, cat, desc: `Buka ${info.n} (dapat senjata). Tanpa angka = buka 1, atau 'all'`, usage: `s${key} [jumlah|all]`,
    async run({ u, args, reply }) {
      const have = D.count(u, key);
      if (!have) return reply({ embeds: [E(`${info.e} ${info.n}`, `Kamu tidak punya ${info.n}.\nDapatkan dari battle, lootbox, atau \`szooshop\`.`)] });
      const n = args[0] ? parseAmt(args[0], have) : 1;
      if (!n || n > have) return reply(`Kamu hanya punya ${have}.`);
      const open = Math.min(n, 25);
      const out = [];
      for (let i = 0; i < open; i++) out.push(...D.openCrate(u, key));
      D.addItem(u, key, -open);
      return reply({ embeds: [E(`${info.e} Membuka ${open}× ${info.n}`, out.join('\n'), { footer: `Sisa: ${D.count(u, key)}` })] });
    },
  };
}

module.exports = [
  {
    name: 'combolist', aliases: ['combo'], cat, desc: 'Daftar combo senjata (bonus saat dipasang di team)', usage: 'scombolist',
    async run({ reply }) {
      return reply({ embeds: [E('🔗 Combo Senjata', D.COMBOS.map(x => `**${x.n}** — ${x.d}\n└ ${x.atk ? `ATK +${x.atk * 100}% ` : ''}${x.hp ? `HP +${x.hp * 100}%` : ''}`).join('\n\n'))] });
    },
  },
  crateCmd('crate', ['cr']),
  crateCmd('legendarycrate', ['lcrate']),
  crateCmd('fabledcrate', ['fcrate']),
  crateCmd('redfabledcrate', ['rfcrate']),
  {
    name: 'dismantle', aliases: ['dm'], cat, desc: 'Bongkar senjata jadi shard. `sdismantle <id|all>`', usage: 'sdismantle <id|all>',
    async run({ u, args, reply }) {
      const a = (args[0] || '').toLowerCase();
      let list;
      if (a === 'all') list = u.weapons.filter(w => !w.animal);
      else { const id = parseInt(a, 10); list = u.weapons.filter(w => w.id === id); }
      if (!list.length) return reply('Senjata tidak ditemukan (senjata yang sedang dipakai tidak ikut `all`).');
      let shard = 0;
      for (const w of list) shard += D.SHARD_VALUE[w.ri];
      const ids = new Set(list.map(w => w.id));
      u.weapons = u.weapons.filter(w => !ids.has(w.id));
      u.shard += shard;
      return reply({ embeds: [E('🔨 Dismantle', `Membongkar **${list.length}** senjata → **+${fmt(shard)}** shard 💎`)] });
    },
  },
  {
    name: 'weapon', aliases: ['w', 'wp'], cat, desc: 'Daftar senjata. `sweapon equip <id> <hewan>`, `sweapon unequip <id>`', usage: 'sweapon [equip <id> <hewan> | unequip <id>]',
    async run({ u, args, reply }) {
      const sub = (args[0] || '').toLowerCase();
      if (sub === 'equip') {
        const w = u.weapons.find(x => x.id === parseInt(args[1], 10));
        const a = D.findAnimal(args[2]);
        if (!w) return reply('Senjata tidak ditemukan.');
        if (!a || !u.team.includes(a.id)) return reply('Hewan harus ada di team (`steam add <hewan>`).');
        u.weapons.forEach(x => { if (x.animal === a.id) x.animal = null; });
        w.animal = a.id;
        return reply({ embeds: [E('⚔️ Equip', `${D.weaponLine(w)}\ndipasang ke ${a.emoji} ${cap(a.name)}`)] });
      }
      if (sub === 'unequip') {
        const w = u.weapons.find(x => x.id === parseInt(args[1], 10));
        if (!w) return reply('Senjata tidak ditemukan.');
        w.animal = null;
        return reply('Senjata dilepas.');
      }
      if (!u.weapons.length) return reply({ embeds: [E('⚔️ Senjata', 'Kamu belum punya senjata. Buka `scrate`!')] });
      const sorted = [...u.weapons].sort((a, b) => b.ri - a.ri || (b.atk + b.hp) - (a.atk + a.hp));
      return reply({ embeds: [E(`⚔️ Senjata (${u.weapons.length})`, sorted.slice(0, 25).map(D.weaponLine).join('\n') + (sorted.length > 25 ? `\n… dan ${sorted.length - 25} lainnya` : ''), { footer: 'sweapon equip <id> <hewan> | sdismantle <id>' })] });
    },
  },
  {
    name: 'weaponinfo', aliases: ['wi'], cat, desc: 'Detail satu senjata', usage: 'sweaponinfo <id>',
    async run({ u, args, reply }) {
      const w = u.weapons.find(x => x.id === parseInt(args[0], 10));
      if (!w) return reply('Senjata tidak ditemukan. Lihat id di `sweapon`.');
      const t = WTYPES[w.type];
      return reply({ embeds: [E(`${t.e} ${cap(w.type)} #${w.id}`, `Rarity: ${RAR[w.ri].e} **${RAR[w.ri].n}**\nATK: **+${w.atk}**\nHP: **+${w.hp}**\nDipakai: ${w.animal ? `${ANIMALS[w.animal].emoji} ${cap(w.animal)}` : 'tidak ada'}\nNilai bongkar: 💎 ${D.SHARD_VALUE[w.ri]}`)] });
    },
  },
];
