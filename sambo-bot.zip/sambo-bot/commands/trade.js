const db = require('../lib/db');
const D = require('../lib/data');
const { E, fmt, parseAmt, getTarget } = require('../lib/util');
const cat = 'Trade';

// kind: 'field' (u[field]) | 'item' (box/crate dari nama)
function tradeCmd({ name, aliases = [], desc, field, store, label, emoji, needName }) {
  return {
    name, aliases, cat, desc, usage: needName ? `s${name} @user <nama> <jumlah>` : `s${name} @user <jumlah>`,
    async run(c) {
      const { u, msg } = c;
      const { user: t, rest } = await getTarget(msg, c.args);
      if (!t || t.bot || t.id === u.id) return c.reply(`Pakai: \`s${name} @user ${needName ? '<nama> ' : ''}<jumlah>\``);
      let key = field, amtArg = rest[0];
      if (needName) {
        key = (rest[0] || '').toLowerCase(); amtArg = rest[1];
        const ok = store === 'items' ? D.BOXES[key] || D.OTHER_ITEMS[key] : D.CRATES[key];
        if (!ok) return c.reply(`Nama tidak valid.\nPilihan: ${Object.keys(store === 'items' ? { ...D.BOXES, ...D.OTHER_ITEMS } : D.CRATES).map(x => `\`${x}\``).join(', ')}`);
      }
      const have = needName ? D.count(u, key) : u[key];
      const n = amtArg ? parseAmt(amtArg, have) : 1;
      if (!n) return c.reply('Jumlah tidak valid.');
      if (n > have) return c.reply('Jumlah kamu tidak cukup.');
      const tu = db.user(t.id);
      if (needName) { D.addItem(u, key, -n); D.addItem(tu, key, n); }
      else { u[key] -= n; tu[key] += n; }
      db.save();
      const nm = needName ? D.ITEM_NAME(key).n : label;
      return c.reply({ embeds: [E('🤝 Transfer', `${emoji} **${msg.author.username}** → **${t.username}**\n**${fmt(n)}× ${nm}**`)] });
    },
  };
}

module.exports = [
  tradeCmd({ name: 'transfer', aliases: ['pay', 'send', 'tf'], desc: 'Kirim coin', field: 'coin', label: 'coin', emoji: '🪙' }),
  tradeCmd({ name: 'transferbox', aliases: ['tbox'], desc: 'Kirim box (lootbox, uwubox, dll)', store: 'items', needName: true, emoji: '📦' }),
  tradeCmd({ name: 'transfercrate', aliases: ['tcrate'], desc: 'Kirim crate', store: 'crates', needName: true, emoji: '🧰' }),
  tradeCmd({ name: 'transferpoint', aliases: ['tpoint'], desc: 'Kirim point', field: 'point', label: 'point', emoji: '✨' }),
  tradeCmd({ name: 'transfershard', aliases: ['tshard'], desc: 'Kirim shard', field: 'shard', label: 'shard', emoji: '💎' }),
  tradeCmd({ name: 'transferspecialticket', aliases: ['tsticket'], desc: 'Kirim special ticket', field: 'specialticket', label: 'special ticket', emoji: '🌟' }),
  tradeCmd({ name: 'transferticket', aliases: ['tticket'], desc: 'Kirim ticket', field: 'ticket', label: 'ticket', emoji: '🎫' }),
];
