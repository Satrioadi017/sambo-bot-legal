const db = require('../lib/db');
const D = require('../lib/data');
const { E, fmt, sleep, pick, parseBet, betError } = require('../lib/util');
const { settle, lobby } = require('../lib/game');
const cat = 'Gamble';

const FEE = 0.1; // potongan 10% dari keuntungan pemenang
const MODES = {
  quick: { name: 'Quick Draw', bullets: 1, emoji: '🔫', desc: '1 peluru di silinder 6 lubang' },
  hard: { name: 'Double Barrel', bullets: 2, emoji: '💀', desc: '2 peluru di silinder 6 lubang (lebih brutal)' },
};
// Animasi GIF (unggah 3 file di folder roulette-assets ke GitHub, lalu isi URL "raw"-nya). Kosongkan untuk melewati gambar.
const RR_IMG = {
  spin: 'https://raw.githubusercontent.com/Satrioadi017/sambo-bot-legal/main/rr_spin.gif',
  bang: 'https://raw.githubusercontent.com/Satrioadi017/sambo-bot-legal/main/rr_bang.gif',
  winner: 'https://raw.githubusercontent.com/Satrioadi017/sambo-bot-legal/main/rr_winner.gif',
};
const withImg = (e, url) => { if (url) e.setImage(url); return e; };
const CLICKS = ['*click*', '*click… huft*', '*click — selamat!*', '*click… keringat dingin*', '*click — masih hidup*'];
const BANGS = ['💥 **BANG!**', '💥 **DOR!** Peluru menemukan sasarannya', '💥 **BANG!** Tamat sudah'];

const shuffle = a => { const r = [...a]; for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; } return r; };
const tag = p => `<@${p.id}>`;

// Satu ronde: pemain hidup bergantian menarik pelatuk sampai ada yang kena
function playRound(alive, bullets) {
  const chamber = [false, false, false, false, false, false];
  let placed = 0;
  while (placed < bullets) { const i = Math.floor(Math.random() * 6); if (!chamber[i]) { chamber[i] = true; placed++; } }
  const order = shuffle(alive);
  const pulls = [];
  for (let i = 0; i < 6; i++) {
    const p = order[i % order.length];
    pulls.push({ p, bang: chamber[i] });
    if (chamber[i]) return { pulls, victim: p };
  }
}
const cylinder = pulls => Array.from({ length: 6 }, (_, i) => (i < pulls.length - 1 ? '⚪' : i === pulls.length - 1 ? '💥' : '🔘')).join(' ');

module.exports = [
  {
    name: 'russianroulette', aliases: ['rr', 'roulette', 'rroulette'], cat,
    desc: 'Russian Roulette multiplayer (2-20 pemain). Pemain terakhir yang hidup membawa seluruh pot. Mode: quick / hard',
    usage: 'srussianroulette <taruhan> [quick|hard]',
    async run(c) {
      const modeKey = (c.args.find(a => MODES[a.toLowerCase()]) || 'quick').toLowerCase();
      const betArg = c.args.find(a => !MODES[a.toLowerCase()]);
      const mode = MODES[modeKey];
      const bet = parseBet(betArg, c.u);
      const err = betError(c.u, bet);
      if (err) return c.reply(`${err}\nPakai: \`srr <taruhan> [quick|hard]\``);
      if (db.busy.has(c.u.id)) return c.reply('Kamu masih punya game aktif.');

      const L = await lobby(c, { title: `🔫 Russian Roulette — ${mode.name}`, bet, min: 2, max: 20, time: 30000 });
      if (!L) return;
      let settled = false;
      try {
        const players = L.list;
        const n = players.length;
        const pot = bet * n;
        let alive = [...players];
        const out = [];
        let round = 0, totalPulls = 0;
        const head = `Entry **${fmt(bet)}** · Mode ${mode.emoji} **${mode.name}** · Players **${n}/20**`;
        const aliveLine = () => `**Hidup (${alive.length}):** ${alive.map(tag).join(' ')}`;

        const m = await c.msg.channel.send({ embeds: [withImg(E(`🔫 Russian Roulette — ${mode.name}`,
          `${head}\n\nSilinder 6 lubang berisi **${mode.bullets} peluru** (${mode.desc}).\nTiap ronde, pemain yang hidup bergantian menarik pelatuk sampai ada yang kena. Yang tersisa **terakhir** membawa seluruh pot!\n\n💰 Pot: **${fmt(pot)}** coin\n${aliveLine()}`), RR_IMG.spin)] });
        await sleep(3000);

        while (alive.length > 1) {
          round++;
          const duel = alive.length === 2;
          const tense = alive.length <= 4;
          const title = duel ? '⚔️ FINAL DUEL' : `🔫 Round ${round}`;
          if (tense) {
            await m.edit({ embeds: [withImg(E(title, `${head}\n\n🌀 Silinder diputar…\n🔘 🔘 🔘 🔘 🔘 🔘\n\n${duel ? 'Hanya tersisa dua orang. Satu akan pulang dengan pot!' : 'Suasana makin tegang…'}\n${aliveLine()}`, { color: 0xfee75c }), RR_IMG.spin)] }).catch(() => {});
            await sleep(2000);
          }
          const r = playRound(alive, mode.bullets);
          totalPulls += r.pulls.length;
          alive = alive.filter(p => p !== r.victim);
          out.push({ p: r.victim, round });
          const lines = r.pulls.map(x => `🔫 ${tag(x.p)} — ${x.bang ? pick(BANGS) : pick(CLICKS)}`).join('\n');
          await m.edit({ embeds: [withImg(E(title, `${head}\n\n${lines}\n\n${cylinder(r.pulls)}\n💀 ${tag(r.victim)} **gugur** di Round ${round}!\n\n${aliveLine()}`, { color: 0xed4245 }), RR_IMG.bang)] }).catch(() => {});
          await sleep(tense ? 3000 : 2000);
        }

        // hasil akhir
        const winner = alive[0];
        const profit = pot - bet;
        const fee = Math.floor(profit * FEE);
        const payout = pot - fee;
        settle(winner.u, bet, payout);
        out.forEach(o => settle(o.p.u, bet, 0));
        settled = true;
        let bonus = '';
        if (n >= 10) { D.addItem(winner.u, 'uwubox', 1); bonus = '\n🎁 Bonus pemenang: **1 Uwu Box** (10+ pemain)'; }
        else if (n >= 4) { D.addItem(winner.u, 'lootbox', 1); bonus = '\n🎁 Bonus pemenang: **1 Lootbox** (4+ pemain)'; }
        db.save();

        const results = [`🥇 \`+${fmt(payout - bet)}\` ${tag(winner)} · survivor`, ...out.map(o => `💀 \`-${fmt(bet)}\` ${tag(o.p)} · Round ${o.round}`)].join('\n');
        await m.edit({ embeds: [withImg(E('🥇 LAST ONE STANDING',
          `${head}\n${round} round · ${totalPulls} pulls · ${n} players\n\n${results}\n\n💰 **Pot** \`${fmt(pot)}\` · dibayarkan \`${fmt(payout)}\` (${FEE * 100}% biaya admin dari keuntungan)${bonus}\n\n_Game selesai · buka meja baru dengan_ \`srr <taruhan>\``,
          { color: 0x57f287 }), RR_IMG.winner)] }).catch(() => c.msg.channel.send({ content: `🥇 ${tag(winner)} menang **${fmt(payout)}** coin!` }));
      } catch (e) {
        if (!settled) L.list.forEach(p => { p.u.coin += bet; }); // refund kalau ada error
        throw e;
      } finally { L.release(); }
    },
  },
];
