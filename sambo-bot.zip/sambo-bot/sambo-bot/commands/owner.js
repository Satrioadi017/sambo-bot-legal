const db = require('../lib/db');
const D = require('../lib/data');
const { E, fmt, getTarget, parseAmt } = require('../lib/util');
const { AttachmentBuilder } = require('discord.js');
const cat = 'Owner';
const FIELDS = ['coin', 'bank', 'shard', 'point', 'xp', 'level', 'ticket', 'specialticket', 'streak'];
const BAD = new Set(['__proto__', 'constructor', 'prototype']);

async function resolve(c, args) {
  const first = (args[0] || '').toLowerCase();
  if (first === 'me' || first === 'saya') return { tu: c.u, rest: args.slice(1) };
  const { user, rest } = await getTarget(c.msg, args);
  if (!user) return { tu: c.u, rest: args, implicit: true };
  return { tu: db.user(user.id), rest, user };
}
function setPath(obj, path, val) {
  const keys = path.split('.');
  if (keys.some(k => BAD.has(k) || !k)) throw new Error('Path tidak valid');
  let o = obj;
  for (let i = 0; i < keys.length - 1; i++) { if (typeof o[keys[i]] !== 'object' || o[keys[i]] === null) o[keys[i]] = {}; o = o[keys[i]]; }
  o[keys[keys.length - 1]] = val;
}
const getPath = (obj, path) => path.split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj);
const parseVal = s => { try { return JSON.parse(s); } catch { return s; } };

module.exports = [
  {
    name: 'ownerhelp', aliases: ['oh'], cat, owner: true, desc: 'Bantuan perintah owner', usage: 'sownerhelp',
    async run({ reply }) {
      return reply({ embeds: [E('👑 Perintah Owner', [
        '`sgive [@user|me] <field> <jumlah>` — tambah (coin, bank, shard, point, xp, level, ticket, specialticket)',
        '`sremove [@user|me] <field> <jumlah>` — kurangi',
        '`sset [@user|me] <field> <angka>` — set nilai',
        '`sgiveitem [@user|me] <item> <jumlah>` — beri box/crate/protectioncard',
        '`sgiveanimal [@user|me] <hewan> <jumlah>` — beri hewan',
        '`sgiveweapon [@user|me] <tipe> <rarity>` — beri senjata',
        '`sedit [@user|me] <path> <nilai JSON>` — ubah data apa pun, mis. `sedit me stats.hunts 999`',
        '`sget [@user|me] [path]` — lihat data user (JSON)',
        '`sresetuser @user` — hapus data user',
        '`sdbbackup` — kirim file database',
        '\nOwner: cooldown & batas taruhan tidak berlaku, saldo coin otomatis terisi.',
      ].join('\n'))] });
    },
  },
  {
    name: 'give', aliases: ['addcoin', 'g'], cat, owner: true, desc: 'Owner: tambah saldo/field', usage: 'sgive [@user|me] <field> <jumlah>',
    async run(c) {
      const { tu, rest, user } = await resolve(c, c.args);
      let field = (rest[0] || 'coin').toLowerCase(), amt = rest[1];
      if (!FIELDS.includes(field)) { amt = rest[0]; field = 'coin'; }
      const n = parseAmt(amt, 0);
      if (!n) return c.reply('Pakai: `sgive [@user|me] <field> <jumlah>`');
      tu[field] += n;
      return c.reply({ embeds: [E('👑 Give', `+**${fmt(n)}** ${field} untuk **${user ? user.username : c.msg.author.username}**\nTotal: ${fmt(tu[field])}`)] });
    },
  },
  {
    name: 'remove', aliases: ['takecoin'], cat, owner: true, desc: 'Owner: kurangi saldo/field', usage: 'sremove [@user|me] <field> <jumlah>',
    async run(c) {
      const { tu, rest, user } = await resolve(c, c.args);
      let field = (rest[0] || 'coin').toLowerCase(), amt = rest[1];
      if (!FIELDS.includes(field)) { amt = rest[0]; field = 'coin'; }
      const n = parseAmt(amt, tu[field]);
      if (!n) return c.reply('Pakai: `sremove [@user|me] <field> <jumlah>`');
      tu[field] = Math.max(0, tu[field] - n);
      return c.reply({ embeds: [E('👑 Remove', `-**${fmt(n)}** ${field} dari **${user ? user.username : c.msg.author.username}**\nTotal: ${fmt(tu[field])}`)] });
    },
  },
  {
    name: 'set', cat, owner: true, desc: 'Owner: set nilai field', usage: 'sset [@user|me] <field> <angka>',
    async run(c) {
      const { tu, rest } = await resolve(c, c.args);
      const field = (rest[0] || '').toLowerCase(); const n = Number(rest[1]);
      if (!FIELDS.includes(field) || !Number.isFinite(n) || n < 0) return c.reply(`Pakai: \`sset [@user|me] <field> <angka>\`\nField: ${FIELDS.join(', ')}`);
      tu[field] = Math.floor(n);
      return c.reply(`✅ ${field} = **${fmt(tu[field])}**`);
    },
  },
  {
    name: 'giveitem', aliases: ['gi', 'gitem'], cat, owner: true, desc: 'Owner: beri item', usage: 'sgiveitem [@user|me] <item> <jumlah>',
    async run(c) {
      const { tu, rest } = await resolve(c, c.args);
      const k = (rest[0] || '').toLowerCase(); const n = parseAmt(rest[1] || '1', 0);
      if (!(D.BOXES[k] || D.CRATES[k] || D.OTHER_ITEMS[k]) || !n) return c.reply(`Pakai: \`sgiveitem [@user|me] <item> <jumlah>\`\nItem: ${[...Object.keys(D.BOXES), ...Object.keys(D.CRATES), ...Object.keys(D.OTHER_ITEMS)].join(', ')}`);
      D.addItem(tu, k, n);
      return c.reply(`✅ +${fmt(n)}× ${D.ITEM_NAME(k).n}`);
    },
  },
  {
    name: 'giveanimal', aliases: ['ga', 'ganimal'], cat, owner: true, desc: 'Owner: beri hewan', usage: 'sgiveanimal [@user|me] <hewan> <jumlah>',
    async run(c) {
      const { tu, rest } = await resolve(c, c.args);
      const a = D.findAnimal(rest[0]); const n = parseAmt(rest[1] || '1', 0);
      if (!a || !n) return c.reply('Pakai: `sgiveanimal [@user|me] <hewan> <jumlah>`');
      D.addAnimal(tu, a.id, n);
      return c.reply(`✅ +${fmt(n)}× ${a.emoji} ${a.name}`);
    },
  },
  {
    name: 'giveweapon', aliases: ['gw', 'gweapon'], cat, owner: true, desc: 'Owner: beri senjata', usage: 'sgiveweapon [@user|me] <tipe> <rarity>',
    async run(c) {
      const { tu, rest } = await resolve(c, c.args);
      const type = (rest[0] || '').toLowerCase(); const ri = D.RAR.findIndex(r => r.k === (rest[1] || '').toLowerCase());
      if (!D.WTYPES[type] || ri < 0) return c.reply(`Pakai: \`sgiveweapon [@user|me] <tipe> <rarity>\`\nTipe: ${Object.keys(D.WTYPES).join(', ')}\nRarity: ${D.RAR.map(r => r.k).join(', ')}`);
      const w = D.makeWeapon(tu, ri, type);
      return c.reply({ embeds: [E('👑 Give Weapon', D.weaponLine(w))] });
    },
  },
  {
    name: 'edit', cat, owner: true, desc: 'Owner: ubah data user apa pun (path + nilai JSON)', usage: 'sedit [@user|me] <path> <nilai>',
    async run(c) {
      const { tu, rest } = await resolve(c, c.args);
      const path = rest[0]; const raw = rest.slice(1).join(' ');
      if (!path || !raw) return c.reply('Pakai: `sedit [@user|me] <path> <nilai JSON>`\nContoh: `sedit me stats.hunts 999`');
      try { setPath(tu, path, parseVal(raw)); } catch (e) { return c.reply('❌ ' + e.message); }
      return c.reply(`✅ \`${path}\` = \`${JSON.stringify(getPath(tu, path)).slice(0, 500)}\``);
    },
  },
  {
    name: 'get', aliases: ['dump'], cat, owner: true, desc: 'Owner: lihat data user', usage: 'sget [@user|me] [path]',
    async run(c) {
      const { tu, rest } = await resolve(c, c.args);
      const v = rest[0] ? getPath(tu, rest[0]) : tu;
      const txt = JSON.stringify(v, null, 2) || 'undefined';
      if (txt.length < 1800) return c.reply('```json\n' + txt + '\n```');
      return c.reply({ files: [new AttachmentBuilder(Buffer.from(txt), { name: 'data.json' })] });
    },
  },
  {
    name: 'resetuser', cat, owner: true, desc: 'Owner: hapus data user', usage: 'sresetuser @user',
    async run(c) {
      const { user } = await getTarget(c.msg, c.args);
      if (!user) return c.reply('Pakai: `sresetuser @user`');
      delete db.raw.users[user.id];
      return c.reply(`✅ Data **${user.username}** dihapus.`);
    },
  },
  {
    name: 'dbbackup', aliases: ['backup'], cat, owner: true, desc: 'Owner: kirim file database', usage: 'sdbbackup',
    async run(c) {
      db.flush();
      return c.reply({ files: [new AttachmentBuilder(Buffer.from(JSON.stringify(db.raw)), { name: 'db-backup.json' })] });
    },
  },
];
