const { PermissionsBitField } = require('discord.js');
const db = require('../lib/db');
const guild = require('../lib/guild');
const { E } = require('../lib/util');

const list = a => (a.length ? a.map(i => `<#${i}>`).join(' ') : '_tidak ada_');

module.exports = [
  {
    name: 'channel', aliases: ['ch', 'setchannel'], cat: 'Info',
    desc: 'Atur channel tempat bot boleh dipakai (perlu izin Manage Server)',
    usage: 'schannel <allow|unallow|block|unblock|list|reset> [#channel]',
    async run(c) {
      const { msg, args, reply } = c;
      const g = guild.cfg(msg.guild.id);
      const sub = (args[0] || 'list').toLowerCase();
      const show = (note = '') => reply({ embeds: [E('📍 Pengaturan Channel Bot',
        `✅ **Channel yang diizinkan:** ${g.allow.length ? list(g.allow) : 'semua channel (tidak dibatasi)'}\n⛔ **Channel yang diblokir:** ${list(g.block)}\n\n` +
        `• \`schannel allow #game\` — bot hanya jalan di channel itu\n• \`schannel block #general\` — matikan bot di channel itu\n• \`schannel unallow\` / \`unblock\` / \`reset\` — batalkan${note ? `\n\n${note}` : ''}`)] });

      if (sub === 'list') return show();
      const can = db.isOwner(msg.author.id) || (msg.member && msg.member.permissions.has(PermissionsBitField.Flags.ManageGuild));
      if (!can) return reply('⛔ Hanya yang punya izin **Manage Server** yang bisa mengatur channel bot.');

      if (sub === 'reset') { g.allow = []; g.block = []; return show('♻️ Pengaturan direset, bot bisa dipakai di semua channel.'); }

      const ids = new Set([...msg.mentions.channels.keys()]);
      args.slice(1).filter(a => /^\d{17,20}$/.test(a)).forEach(a => ids.add(a));
      if (!ids.size) ids.add(msg.channel.id);
      const valid = [...ids].filter(id => msg.guild.channels.cache.has(id));
      if (!valid.length) return reply('Channel tidak ditemukan di server ini.');

      const add = (arr, xs) => { xs.forEach(x => { if (!arr.includes(x)) arr.push(x); }); };
      const del = (arr, xs) => arr.filter(x => !xs.includes(x));
      if (sub === 'allow') { add(g.allow, valid); g.block = del(g.block, valid); }
      else if (sub === 'unallow') g.allow = del(g.allow, valid);
      else if (sub === 'block') { add(g.block, valid); g.allow = del(g.allow, valid); }
      else if (sub === 'unblock') g.block = del(g.block, valid);
      else return reply('Pakai: `schannel <allow|unallow|block|unblock|list|reset> [#channel]`');
      return show(sub === 'allow' ? '✅ Channel ditambahkan. Di channel lain bot sekarang diam.' : '');
    },
  },
];
