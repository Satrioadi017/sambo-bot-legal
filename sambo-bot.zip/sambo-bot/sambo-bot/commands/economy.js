const db = require('../lib/db');
const D = require('../lib/data');
const { E, fmt, cap, dur, cooldown, rand, pick, getTarget, parseAmt, addXp, xpNeed, QUEST_DEFS, ensureQuests, track } = require('../lib/util');

const bar = (v, m, len = 12) => { const f = Math.max(0, Math.min(len, Math.round((v / m) * len))); return '█'.repeat(f) + '░'.repeat(len - f); };
const cat = 'Items';

module.exports = [
  {
    name: 'balance', aliases: ['bal', 'cash', 'coin'], cat, desc: 'Lihat saldo coin, bank, shard, dll.', usage: 'sbalance [@user]',
    async run(c) {
      const { user: t } = await getTarget(c.msg, c.args);
      if (t && db.isOwner(t.id) && !db.isOwner(c.u.id)) return c.reply('🔒 Yahaha Saldo owner disembunyikan.');
      if (t && t.id !== c.u.id && !db.isOwner(c.u.id)) return c.reply('🔒 Nono ngintip Saldo pemain lain disembunyikan.');
      const tu = t ? db.user(t.id) : c.u;
      const name = (t || c.msg.author).username;
      return c.reply({ embeds: [E(`💰 Saldo ${name}${db.isOwner(tu.id) ? ' 👑' : ''}`,
        `🪙 Coin: **${fmt(tu.coin)}**\n🏦 Bank: **${fmt(tu.bank)}**\n💎 Shard: **${fmt(tu.shard)}**\n✨ Point: **${fmt(tu.point)}**\n🎫 Ticket: **${fmt(tu.ticket)}**\n🌟 Special Ticket: **${fmt(tu.specialticket)}**`)] });
    },
  },
  {
    name: 'daily', cat, desc: 'Hadiah harian (streak = bonus)', usage: 'sdaily',
    async run({ u, reply }) {
      const last = u.cd.daily || 0;
      const rem = cooldown(u, 'daily', 864e5);
      if (rem) return reply({ embeds: [E('⏳ Daily', `Kamu sudah klaim. Coba lagi dalam **${dur(rem)}**.`)] });
      u.streak = last && Date.now() - last < 1728e5 ? u.streak + 1 : 1;
      const coin = 500 + Math.min(u.streak, 30) * 50;
      u.coin += coin;
      let extra = '';
      if (u.streak % 7 === 0) { D.addItem(u, 'lootbox', 1); extra = '\n📦 Bonus streak: 1 Lootbox!'; }
      return reply({ embeds: [E('🎁 Daily', `+**${fmt(coin)}** coin\n🔥 Streak: **${u.streak}** hari${extra}${addXp(u, 20)}`)] });
    },
  },
  {
    name: 'weekly', cat, desc: 'Hadiah mingguan', usage: 'sweekly',
    async run({ u, reply }) {
      const rem = cooldown(u, 'weekly', 6048e5);
      if (rem) return reply({ embeds: [E('⏳ Weekly', `Coba lagi dalam **${dur(rem)}**.`)] });
      u.coin += 5000; u.ticket += 1; D.addItem(u, 'lootbox', 2); D.addItem(u, 'uwubox', 1);
      return reply({ embeds: [E('🎉 Weekly', `+**5,000** coin\n🎫 +1 Ticket\n📦 +2 Lootbox\n🎁 +1 Uwu Box${addXp(u, 80)}`)] });
    },
  },
  {
    name: 'work', aliases: ['wk'], cat, desc: 'Bekerja untuk dapat coin (cooldown 1 menit)', usage: 'swork',
    async run({ u, reply }) {
      const rem = cooldown(u, 'work', 60000);
      if (rem) return reply(`⏳ Kamu masih lelah. Tunggu **${dur(rem)}**.`);
      const jobs = ['🧑‍🍳 memasak nasi goreng', '🧑‍🌾 memanen padi', '👷 membangun rumah', '🧑‍💻 mengetik kode', '🚕 menyetir taksi', '🎣 menjual ikan'];
      const coin = rand(80, 300) + u.level * 5;
      u.coin += coin; u.stats.worked++; track(u, 'work');
      let extra = '';
      if (Math.random() < 0.03) { u.shard += 1; extra = '\n💎 Kamu menemukan 1 shard!'; }
      return reply({ embeds: [E('💼 Work', `Kamu ${pick(jobs)} dan dapat **${fmt(coin)}** coin.${extra}${addXp(u, 8)}`)] });
    },
  },
  {
    name: 'deposit', aliases: ['dep'], cat, desc: 'Simpan coin ke bank', usage: 'sdeposit <jumlah|all>',
    async run({ u, args, reply }) {
      const n = parseAmt(args[0], u.coin);
      if (!n || n > u.coin) return reply('Jumlah tidak valid atau coin tidak cukup.');
      u.coin -= n; u.bank += n;
      return reply({ embeds: [E('🏦 Deposit', `Menyimpan **${fmt(n)}** coin.`)] });
    },
  },
  {
    name: 'withdraw', aliases: ['wd'], cat, desc: 'Ambil coin dari bank', usage: 'swithdraw <jumlah|all>',
    async run({ u, args, reply }) {
      const n = parseAmt(args[0], u.bank);
      if (!n || n > u.bank) return reply('Jumlah tidak valid atau saldo bank tidak cukup.');
      u.bank -= n; u.coin += n;
      return reply({ embeds: [E('🏦 Withdraw', `Mengambil **${fmt(n)}** coin.`)] });
    },
  },
  {
    name: 'level', aliases: ['lvl', 'lv'], cat, desc: 'Lihat level & XP', usage: 'slevel',
    async run({ u, reply, msg }) {
      const need = xpNeed(u.level);
      const boost = (u.boosts.level || 0) > Date.now() ? `\n⚡ Boost XP x2 aktif (${dur(u.boosts.level - Date.now())})` : '';
      return reply({ embeds: [E(`⭐ Level ${msg.author.username}`, `Level **${u.level}**\n${bar(u.xp, need)} ${fmt(u.xp)}/${fmt(need)} XP${boost}`)] });
    },
  },
  {
    name: 'boostlevel', aliases: ['bl'], cat, desc: 'Beli boost XP x2 selama 1 jam (2,000 coin)', usage: 'sboostlevel',
    async run({ u, reply }) {
      if (u.coin < 2000) return reply('Butuh 2,000 coin.');
      u.coin -= 2000;
      u.boosts.level = Math.max(Date.now(), u.boosts.level || 0) + 36e5;
      return reply({ embeds: [E('⚡ Boost Level', `XP x2 aktif selama **${dur(u.boosts.level - Date.now())}**.`)] });
    },
  },
  {
    name: 'mystats', aliases: ['stats', 'profile'], cat, desc: 'Statistik kamu', usage: 'smystats',
    async run({ u, reply, msg }) {
      const s = u.stats;
      const animals = Object.values(u.animals).reduce((a, b) => a + b, 0);
      return reply({ embeds: [E(`📊 Statistik ${msg.author.username}${db.isOwner(u.id) ? ' 👑' : ''}`,
        `⭐ Level: **${u.level}**\n🐾 Hewan: **${fmt(animals)}** (dex ${Object.keys(u.dex).length}/${D.ANIMAL_LIST.length})\n⚔️ Senjata: **${u.weapons.length}**\n🏹 Hunt: **${fmt(s.hunts)}**\n🛡️ Battle: **${s.battleWin}** menang / **${s.battleLose}** kalah\n🤺 PvP: **${s.pvpWin}** menang / **${s.pvpLose}** kalah\n🎲 Gamble: **${s.gambleWin}** menang / **${s.gambleLose}** kalah\n💼 Work: **${s.worked}**${u.clan ? `\n🏰 Clan: **${u.clan}**` : ''}`)] });
    },
  },
  {
    name: 'quest', aliases: ['q', 'quests'], cat, desc: 'Quest harian. Pakai `squest claim` untuk ambil hadiah', usage: 'squest [claim]',
    async run({ u, args, reply }) {
      const q = ensureQuests(u);
      if ((args[0] || '').toLowerCase() === 'claim') {
        let total = 0, n = 0;
        for (const d of QUEST_DEFS) if ((q.prog[d.id] || 0) >= d.goal && !q.claimed[d.id]) { q.claimed[d.id] = true; total += d.coin; n++; }
        if (!n) return reply('Belum ada quest selesai yang bisa diklaim.');
        u.coin += total; D.addItem(u, 'lootbox', n);
        return reply({ embeds: [E('✅ Quest Diklaim', `+**${fmt(total)}** coin dan **${n}** Lootbox${addXp(u, 25 * n)}`)] });
      }
      const lines = QUEST_DEFS.map(d => {
        const p = Math.min(q.prog[d.id] || 0, d.goal);
        return `${q.claimed[d.id] ? '✅' : p >= d.goal ? '🎯' : '▫️'} **${d.t}** — ${p}/${d.goal} (${fmt(d.coin)} coin + 📦)`;
      });
      return reply({ embeds: [E('📜 Quest Harian', lines.join('\n') + '\n\nKlaim dengan `squest claim`.')] });
    },
  },
  {
    name: 'ranking', aliases: ['rank', 'top', 'lb'], cat, desc: 'Papan peringkat: coin / level / hunt / wins', usage: 'sranking [coin|level|hunt|wins]',
    async run({ u, args, reply, client }) {
      const t = (args[0] || 'coin').toLowerCase();
      const keys = { coin: x => x.coin + x.bank, level: x => x.level * 1e6 + x.xp, hunt: x => x.stats.hunts, wins: x => x.stats.battleWin + x.stats.pvpWin };
      const label = { coin: 'Coin', level: 'Level', hunt: 'Hunt', wins: 'Kemenangan' };
      if (!keys[t]) return reply('Pilihan: `coin`, `level`, `hunt`, `wins`.');
      const all = Object.values(db.raw.users).filter(x => !db.isOwner(x.id)).sort((a, b) => keys[t](b) - keys[t](a)).slice(0, 10);
      const names = await Promise.all(all.map(x => client.users.fetch(x.id).then(r => r.username).catch(() => x.id)));
      const show = x => (t === 'level' ? `Lv ${x.level}` : fmt(keys[t](x)));
      const medals = ['🥇', '🥈', '🥉'];
      return reply({ embeds: [E(`🏆 Ranking ${label[t]}`, all.map((x, i) => `${medals[i] || `**${i + 1}.**`} ${names[i]} — ${show(x)}`).join('\n') || 'Belum ada data.')] });
    },
  },
];
