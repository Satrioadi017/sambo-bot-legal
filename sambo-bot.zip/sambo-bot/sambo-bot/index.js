require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Partials, ActivityType } = require('discord.js');
const db = require('./lib/db');
const registry = require('./lib/registry');
const guildCfg = require('./lib/guild');
const { E } = require('./lib/util');

if (!process.env.DISCORD_TOKEN) { console.error('DISCORD_TOKEN belum diisi di file .env'); process.exit(1); }

const client = new Client({
     intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.DirectMessages],
     partials: [Partials.Channel], // wajib agar pesan DM terbaca
   });

for (const f of fs.readdirSync(path.join(__dirname, 'commands')).filter(x => x.endsWith('.js'))) {
  for (const c of require('./commands/' + f)) {
    registry.list.push(c);
    registry.map.set(c.name, c);
    (c.aliases || []).forEach(a => { if (!registry.map.has(a)) registry.map.set(a, c); });
  }
}

client.once('clientReady', () => {
  console.log(`Sambo Bot online sebagai ${client.user.tag} | ${registry.list.length} perintah`);
  client.user.setActivity('shelp | Sambo Bot', { type: ActivityType.Playing });
});

const lastCmd = new Map();
const warned = new Map();
const GUILD_ONLY = new Set(['slotsmultiplayer', 'blackjackmultiplayer', 'pokkdeangmultiplayer', 'klahklokmultiplayer', 'russianroulette', 'battlepvp', 'channel']);
client.on('messageCreate', async msg => {
  if (msg.author.bot) return;
  const content = msg.content.trim();
  if (content.length < 2 || content[0].toLowerCase() !== 's') return;
  const parts = content.slice(1).trim().split(/\s+/);
  const name = (parts.shift() || '').toLowerCase();
  const cmd = registry.map.get(name);
  if (!cmd) return;

  const reply = p => msg.reply(typeof p === 'string'
    ? { content: p, allowedMentions: { parse: [], repliedUser: false } }
    : { allowedMentions: { parse: [], repliedUser: false }, ...p });

  try {
    if (cmd.owner && !db.isOwner(msg.author.id)) return reply('⛔ Perintah ini hanya untuk owner bot.');
    if (!msg.guild && GUILD_ONLY.has(cmd.name)) return reply('ℹ️ Perintah ini hanya bisa dipakai di server, bukan di DM.');
    if (msg.guild && cmd.cat !== 'Info' && !db.isOwner(msg.author.id)) {
        const ch = msg.channel;
        if (!guildCfg.allowed(msg.guild.id, ch.id, ch.isThread() ? ch.parentId : null)) {
          const key = msg.guild.id + ch.id; const now = Date.now();
          if (now - (warned.get(key) || 0) > 10000) {
            warned.set(key, now);
            const g = guildCfg.cfg(msg.guild.id);
            const where = g.allow.length ? `Gunakan bot di ${g.allow.map(i => `<#${i}>`).join(' ')}.` : 'Channel ini tidak dipakai untuk bot.';
            const m = await reply(`🚫 Matane, jangan main disini. ${where}`);
            setTimeout(() => m.delete().catch(() => {}), 8000);
          }
          return;
        }
      }
    if (!db.isOwner(msg.author.id)) {
      const now = Date.now();
      if (now - (lastCmd.get(msg.author.id) || 0) < 1500) return;
      lastCmd.set(msg.author.id, now);
    }
    const u = db.user(msg.author.id);
    await cmd.run({ msg, args: parts, u, client, reply });
    db.save();
  } catch (e) {
    console.error(`Error pada perintah ${name}:`, e);
    if (cmd.cat === 'Gamble') db.busy.delete(msg.author.id);
    reply({ embeds: [E('⚠️ Error', 'Terjadi kesalahan saat menjalankan perintah.')] }).catch(() => {});
  }
});

client.login(process.env.DISCORD_TOKEN);
