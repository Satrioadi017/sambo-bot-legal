// Jalankan dari folder bot:  node hide-saldo.js
// Menghapus tampilan saldo dari balasan game, deposit, withdraw, dan total coin di `smystats`.
// Perintah `sbalance` tetap menampilkan saldo seperti biasa. Aman dijalankan berulang kali.
const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, 'commands');
const rules = [
  [/\\nSaldo: \$\{fmt\([^)]*\)\}/g, 'baris "Saldo: ..." di hasil game'],
  [/\\nBank: \*\*\$\{fmt\(u\.bank\)\}\*\* \| Dompet: \*\*\$\{fmt\(u\.coin\)\}\*\*/g, 'baris "Bank | Dompet" di deposit/withdraw'],
  [/\\n🪙 Total coin: \*\*\$\{fmt\(u\.coin \+ u\.bank\)\}\*\*/g, 'baris "Total coin" di smystats'],
];

let total = 0;
for (const f of fs.readdirSync(dir).filter(x => x.endsWith('.js'))) {
  const file = path.join(dir, f);
  let src = fs.readFileSync(file, 'utf8');
  let changed = false;
  for (const [re, label] of rules) {
    const n = (src.match(re) || []).length;
    if (n) { src = src.replace(re, ''); total += n; changed = true; console.log(`${f}: hapus ${n}× ${label}`); }
  }
  if (changed) fs.writeFileSync(file, src);
}
console.log(total ? `Selesai: ${total} perubahan. Sekarang jalankan: pm2 restart sambo-bot` : 'Tidak ada yang perlu diubah (sudah bersih).');
