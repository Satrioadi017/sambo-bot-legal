require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, ActivityType } = require('discord.js');
const db = require('./lib/db');
const registry = require('./lib/registry');
const { E } = require('./lib/util');

if (!process.env.DISCORD_TOKEN) { console.error('DISCORD_TOKEN belum diisi di file .env'); process.exit(1); }

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });

for (const f of fs.readdirSync(path.join(__dirname, 'commands')).filter(x => x.endsWith('.js'))) {
  for (const c of require('./commands/' + f)) {
    registry.list.push(c);
    registry.map.set(c.name, c);
    (c.aliases || []).forEach(a => { if (!registry.map.has(a)) registry.map.set(a, c); });
  }
}

client.once('ready', () => {
  console.log(`Sambo Bot online sebagai ${client.user.tag} | ${registry.list.length} perintah`);
  client.user.setActivity('shelp | Sambo Bot', { type: ActivityType.Playing });
});

const lastCmd = new Map();
client.on('messageCreate', async msg => {
  if (msg.author.bot || !msg.guild) return;
  const content = msg.content.trim();
  if (content.length < 2 || content[0].toLowerCase() !== 's') return;
  const parts = content.slice(1).trim().split(/\s+/);
  const name = (parts.shift() || '').toLowerCase();
  const cmd = registry.map.get(name);
  if (!cmd) return;

  const reply = p => msg.reply(typeof p === 'string'
    ? { content: p, allowedMentions: { parse: [], repliedUser: false } }
    : { allowedMentions: { parse: [], repliedUser: false }, ...p });

  try {
    if (cmd.owner && !db.isOwner(msg.author.id)) return reply('⛔ Perintah ini hanya untuk owner bot.');
    if (!db.isOwner(msg.author.id)) {
      const now = Date.now();
      if (now - (lastCmd.get(msg.author.id) || 0) < 1500) return;
      lastCmd.set(msg.author.id, now);
    }
    const u = db.user(msg.author.id);
    await cmd.run({ msg, args: parts, u, client, reply });
    db.save();
  } catch (e) {
    console.error(`Error pada perintah ${name}:`, e);
    if (cmd.cat === 'Gamble') db.busy.delete(msg.author.id);
    reply({ embeds: [E('⚠️ Error', 'Terjadi kesalahan saat menjalankan perintah.')] }).catch(() => {});
  }
});

client.login(process.env.DISCORD_TOKEN);
